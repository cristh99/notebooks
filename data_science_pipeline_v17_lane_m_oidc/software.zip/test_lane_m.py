from __future__ import annotations

import copy
import json
import tempfile
import unittest
from pathlib import Path

import verify_lane_m as v

HERE = Path(__file__).resolve().parent
SUBJECT = json.loads((HERE / "LANE_M_SIGNATURE_SUBJECT.json").read_text())
RECEIPT = json.loads((HERE / "LANE_M_CANONICAL_RECEIPT.json").read_text())


class LaneMTests(unittest.TestCase):
    def bad_subject(self, mutate, message):
        subject = copy.deepcopy(SUBJECT)
        mutate(subject)
        with self.assertRaisesRegex(v.VerificationError, message):
            v.validate_subject(subject, copy.deepcopy(RECEIPT))

    def bad_receipt(self, mutate, message):
        receipt = copy.deepcopy(RECEIPT)
        mutate(receipt)
        with self.assertRaisesRegex(v.VerificationError, message):
            v.validate_receipt(receipt)

    def test_01_baseline_subject_and_receipt(self):
        v.validate_receipt(copy.deepcopy(RECEIPT))
        v.validate_subject(copy.deepcopy(SUBJECT), copy.deepcopy(RECEIPT))

    def test_02_exact_files_load(self):
        subject, receipt = v.load_and_validate()
        self.assertEqual(subject, SUBJECT)
        self.assertEqual(receipt, RECEIPT)

    def test_03_subject_schema_rejected(self):
        self.bad_subject(lambda x: x.__setitem__("schema", "x"), "subject schema")

    def test_04_lane_or_pr_drift_rejected(self):
        self.bad_subject(lambda x: x.__setitem__("lane", "E"), "lane/PR")

    def test_05_receipt_file_binding_rejected(self):
        self.bad_subject(lambda x: x["receipt_binding"].__setitem__("canonical_receipt_file_sha256", "0" * 64), "receipt file")

    def test_06_receipt_self_binding_rejected(self):
        self.bad_subject(lambda x: x["receipt_binding"].__setitem__("canonical_receipt_self_hash_sha256", "0" * 64), "receipt self-hash")

    def test_07_event_universe_binding_rejected(self):
        self.bad_subject(lambda x: x["receipt_binding"].__setitem__("event_universe_sha256", "0" * 64), "universe")

    def test_08_source_commitment_rejected(self):
        self.bad_subject(lambda x: x["source_commitments"].__setitem__("sefin_raw_artifact_sha256", "0" * 64), "source commitment")

    def test_09_event_order_rejected(self):
        self.bad_subject(lambda x: x["events"].reverse(), "event order")

    def test_10_contract_role_rejected(self):
        self.bad_subject(lambda x: x["events"][0].__setitem__("amount_role", "PAYMENT_VALUE"), "contract mismatch")

    def test_11_payment_role_rejected(self):
        self.bad_subject(lambda x: x["events"][1].__setitem__("date_role", "CONTRACT_DATE"), "payment mismatch")

    def test_12_method_drift_rejected(self):
        self.bad_subject(lambda x: x["events"][0].__setitem__("procurement_method", "direct"), "procurement method")

    def test_13_bid_count_inference_rejected(self):
        self.bad_subject(lambda x: x["events"][0].__setitem__("bid_count", 0), "bid count")

    def test_14_sefin_document_inference_rejected(self):
        self.bad_subject(lambda x: x["events"][1].__setitem__("source_document", "invented.pdf"), "source document")

    def test_15_relationship_promotion_rejected(self):
        self.bad_subject(lambda x: x["semantic_guards"].__setitem__("relationship_state", "MATCH_VALIDATED"), "relationship state")

    def test_16_cross_role_aggregation_rejected(self):
        self.bad_subject(lambda x: x["semantic_guards"].__setitem__("cross_role_aggregation_performed", True), "cross_role_aggregation")

    def test_17_stage08_promotion_rejected(self):
        self.bad_subject(lambda x: x["governance"].__setitem__("stage08_unblocked", True), "stage08_unblocked")

    def test_18_receipt_self_hash_rejected(self):
        self.bad_receipt(lambda x: x.__setitem__("receipt_sha256", "0" * 64), "self-hash field")

    def test_19_receipt_event_merge_rejected(self):
        self.bad_receipt(lambda x: x.__setitem__("equal_amounts_interpreted_as_same_event", True), "equal amounts cannot merge")

    def test_20_noncanonical_file_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            subject_path = Path(tmp) / "subject.json"
            subject_path.write_text(json.dumps(SUBJECT, indent=2) + "\n")
            with self.assertRaisesRegex(v.VerificationError, "canonical"):
                v.load_canonical(subject_path, v.SUBJECT_SHA256, "subject")


if __name__ == "__main__":
    unittest.main(verbosity=2)
