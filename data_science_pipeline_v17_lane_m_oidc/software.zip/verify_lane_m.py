from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path
from typing import Any

HERE = Path(__file__).resolve().parent
SUBJECT = HERE / "LANE_M_SIGNATURE_SUBJECT.json"
RECEIPT = HERE / "LANE_M_CANONICAL_RECEIPT.json"

SUBJECT_SHA256 = "f5e5b0bdccb03434d12e77e89d70a08d437fcd5dcba2280f0708e7106bd3f52c"
RECEIPT_FILE_SHA256 = "58c91cb40de6fe461fbd05a793ff5ebad3f5e419071fb3096aaa1a4b92ac57bb"
RECEIPT_SELF_SHA256 = "07b98a4d12ab69d0e431c6fcfc8a5e351c2baca3456e5d05f572c58f953b6548"
EVENT_UNIVERSE_SHA256 = "e53c65bd2c78979809f98051c25dd3f6239f7a4c5966578a30fcd8ecab1db88f"
REVIEW_ITEM_SHA256 = "39bd1c485c703ef371c2b57a68987f5781697197cc422c14aaa686bd9cc06f2d"
SHA_RE = re.compile(r"^[0-9a-f]{64}$")
SECRET_KEY = re.compile(
    r"(^|[_-])(secret|password|private[_-]?key|credential|api[_-]?key|access[_-]?token|auth[_-]?token)($|[_-])",
    re.I,
)
EVENTS = [
    "lane-v17:contract:e49e3465608c7c4d86ed75f7fdbcdb4de0e0b06edb7d5700609b555dc4122053",
    "lane-v17:payment:355f019de733e170c264b707778f850785572e36f8cd836b745f002ca5662eb3",
]
SOURCE_HASHES = {
    "ONCAE": "6815273455df3694955fe2804cfb26831df40b064f89c9ba252a4f4ed330ef30",
    "SEFIN": "153aefc7095cee5d5225d3d81ae775d2daf3ec554b6e56a7b69cd9b890bc0eb4",
}
SOURCE_COMMITMENTS = {
    "inspector_receipt_sha256": "7b18e89390fa93850155af058c5a951a1cfc395de0083f01d87e73f83385322e",
    "oncae_compiled_release_sha256": "4e1b0aa5e69a065932273f187540bcef48fa01698750680d63358e039f693219",
    "oncae_raw_artifact_sha256": "b31907dfa36e307136684d8fcd7849d4aa0d76181c4c79bdd1822151a50231e3",
    "oncae_source_record_sha256": SOURCE_HASHES["ONCAE"],
    "sefin_raw_artifact_sha256": "cbc4083d4b27c637f6d1daf21a0971450d0b4cb65309ba3d161ac59e58003405",
    "sefin_source_record_sha256": SOURCE_HASHES["SEFIN"],
}


class VerificationError(ValueError):
    pass


def require(condition: bool, message: str) -> None:
    if not condition:
        raise VerificationError(message)


def canonical_bytes(value: object) -> bytes:
    return (
        json.dumps(
            value,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        )
        + "\n"
    ).encode("utf-8")


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def walk(value: object, path: str = "$") -> None:
    if isinstance(value, dict):
        for key, child in value.items():
            require(not SECRET_KEY.search(str(key)), f"credential-like key at {path}.{key}")
            walk(child, f"{path}.{key}")
    elif isinstance(value, list):
        for index, child in enumerate(value):
            walk(child, f"{path}[{index}]")


def load_canonical(path: Path, expected_sha256: str, label: str) -> dict[str, Any]:
    raw = path.read_bytes()
    value = json.loads(raw)
    require(raw == canonical_bytes(value), f"{label} is not canonical JSON")
    require(hashlib.sha256(raw).hexdigest() == expected_sha256, f"{label} SHA-256 mismatch")
    return value


def validate_receipt(receipt: dict[str, Any]) -> None:
    walk(receipt)
    require(receipt.get("schema") == "data-science-pipeline/lane-m-cross-source-receipt/1", "receipt schema mismatch")
    require(receipt.get("coordination_id") == "COORD-2026-08-06-PARALLEL-V2", "receipt coordination mismatch")
    require(receipt.get("event_universe_sha256") == EVENT_UNIVERSE_SHA256, "receipt universe mismatch")
    require(receipt.get("review_item_commitment_sha256") == REVIEW_ITEM_SHA256, "receipt review item mismatch")
    require(receipt.get("canonical_promotion") is False, "receipt promotion forbidden")
    require(receipt.get("cross_role_aggregation_performed") is False, "cross-role aggregation forbidden")
    require(receipt.get("equal_amounts_observed") is True, "equal amounts observation missing")
    require(receipt.get("equal_amounts_interpreted_as_same_event") is False, "equal amounts cannot merge events")
    require(receipt.get("source_document_missing") == ["SEFIN_SOURCE_DOCUMENT"], "source document boundary mismatch")

    embedded = receipt.get("receipt_sha256")
    require(embedded == RECEIPT_SELF_SHA256, "receipt self-hash field mismatch")
    unsigned = dict(receipt)
    unsigned.pop("receipt_sha256")
    require(hashlib.sha256(canonical_bytes(unsigned)).hexdigest() == embedded, "receipt self-hash recomputation mismatch")

    events = receipt.get("events")
    require(isinstance(events, list) and len(events) == 2, "receipt must contain two events")
    require([row.get("event_id") for row in events] == EVENTS, "receipt event order/IDs mismatch")
    require({row.get("event_role") for row in events} == {"CONTRACT", "PAYMENT"}, "receipt role set mismatch")
    require(all(row.get("amount_hnl_cents") == 8162700 for row in events), "receipt amount mismatch")
    require(all(row.get("currency") == "HNL" for row in events), "receipt currency mismatch")
    require(all(row.get("bid_count") is None for row in events), "receipt null bid count must be preserved")
    require(all(row.get("procurement_method") is None for row in events), "receipt original method must remain null")
    for row in events:
        source = row.get("source")
        require(source in SOURCE_HASHES, "receipt source mismatch")
        require(row.get("source_record_sha256") == SOURCE_HASHES[source], "receipt source-record mismatch")
        require(bool(SHA_RE.fullmatch(str(row.get("process_id_commitment_sha256", "")))), "process commitment invalid")
    contract, payment = events
    require(
        (contract.get("event_role"), contract.get("amount_role"), contract.get("date_role"), contract.get("event_date"))
        == ("CONTRACT", "CONTRACT_VALUE", "CONTRACT_DATE", "2024-04-29"),
        "contract role/date mismatch",
    )
    require(
        (payment.get("event_role"), payment.get("amount_role"), payment.get("date_role"), payment.get("event_date"))
        == ("PAYMENT", "PAYMENT_VALUE", "PAYMENT_DATE", "2024-07-17"),
        "payment role/date mismatch",
    )


def validate_subject(subject: dict[str, Any], receipt: dict[str, Any]) -> None:
    walk(subject)
    require(subject.get("schema") == "data-science-pipeline/lane-m-independent-signature-subject/1", "subject schema mismatch")
    require(subject.get("coordination_id") == "COORD-2026-08-06-PARALLEL-V2", "subject coordination mismatch")
    require(
        (subject.get("lane"), subject.get("canonical_pr"), subject.get("arbiter_pr"), subject.get("source_lane_pr"))
        == ("M", 144, 138, 137),
        "subject lane/PR mismatch",
    )

    binding = subject.get("receipt_binding", {})
    require(binding.get("canonical_receipt_file_sha256") == RECEIPT_FILE_SHA256, "receipt file binding mismatch")
    require(binding.get("canonical_receipt_self_hash_sha256") == RECEIPT_SELF_SHA256, "receipt self-hash binding mismatch")
    require(binding.get("event_universe_sha256") == EVENT_UNIVERSE_SHA256, "subject universe binding mismatch")
    require(binding.get("review_item_commitment_sha256") == REVIEW_ITEM_SHA256, "subject review binding mismatch")
    require(subject.get("source_commitments") == SOURCE_COMMITMENTS, "source commitment mismatch")
    require(all(SHA_RE.fullmatch(value) for value in SOURCE_COMMITMENTS.values()), "source commitment format mismatch")

    events = subject.get("events")
    require(isinstance(events, list) and len(events) == 2, "subject must contain two events")
    require([row.get("event_id") for row in events] == EVENTS, "subject event order/IDs mismatch")
    contract, payment = events
    require(
        (
            contract.get("event_role"),
            contract.get("amount_role"),
            contract.get("date_role"),
            contract.get("event_date"),
            contract.get("source"),
            contract.get("source_record_sha256"),
        )
        == (
            "CONTRACT",
            "CONTRACT_VALUE",
            "CONTRACT_DATE",
            "2024-04-29",
            "ONCAE",
            SOURCE_HASHES["ONCAE"],
        ),
        "subject contract mismatch",
    )
    require(contract.get("amount_hnl_cents") == 8162700 and contract.get("currency") == "HNL", "subject contract amount mismatch")
    require(contract.get("procurement_method") == "open", "subject procurement method mismatch")
    require(contract.get("procurement_method_details") == "Convenio Marco", "subject procurement method details mismatch")
    require(contract.get("bid_count") is None, "subject bid count must remain null")
    require(contract.get("bid_count_status") == "ABSTAIN_MISSING_EXPLICIT_FIELD", "subject bid count status mismatch")
    require(
        (
            payment.get("event_role"),
            payment.get("amount_role"),
            payment.get("date_role"),
            payment.get("event_date"),
            payment.get("source"),
            payment.get("source_record_sha256"),
        )
        == (
            "PAYMENT",
            "PAYMENT_VALUE",
            "PAYMENT_DATE",
            "2024-07-17",
            "SEFIN",
            SOURCE_HASHES["SEFIN"],
        ),
        "subject payment mismatch",
    )
    require(payment.get("amount_hnl_cents") == 8162700 and payment.get("currency") == "HNL", "subject payment amount mismatch")
    require(payment.get("source_document") is None, "subject source document must remain null")
    require(
        payment.get("source_document_status") == "ABSTAIN_MISSING_EXPLICIT_DOCUMENT_REF",
        "subject source document status mismatch",
    )

    guards = subject.get("semantic_guards", {})
    require(guards.get("relationship_state") == "CANDIDATE_REVIEW", "relationship state mismatch")
    require(guards.get("null_bid_count_preserved") is True, "null bid count guard mismatch")
    for field in (
        "cross_role_aggregation_performed",
        "cross_source_relationship_asserted",
        "empty_tenderers_interpreted_as_zero",
        "equal_amounts_interpreted_as_same_event",
    ):
        require(guards.get(field) is False, f"{field} must be false")

    governance = subject.get("governance", {})
    require(governance.get("external_cost_usd") == 0.0, "external cost mismatch")
    require(governance.get("scientific_promotion_credit") == 0, "scientific credit mismatch")
    for field in ("mass_processing_authorized", "merge_authorized", "production_modified", "stage08_unblocked"):
        require(governance.get(field) is False, f"{field} must be false")

    boundary = subject.get("claim_boundary", {})
    require(len(boundary.get("establishes_after_valid_signature", [])) == 4, "positive claim boundary mismatch")
    require(len(boundary.get("does_not_establish", [])) == 8, "negative claim boundary mismatch")
    for required in ("SEFIN source document existence", "explicit bid count", "Stage 08 readiness"):
        require(required in boundary["does_not_establish"], f"claim exclusion missing: {required}")

    receipt_events = receipt["events"]
    for srow, rrow in zip(events, receipt_events):
        for field in ("event_id", "event_role", "amount_role", "date_role", "event_date", "amount_hnl_cents", "currency", "source", "source_record_sha256"):
            require(srow.get(field) == rrow.get(field), f"subject/receipt event binding mismatch: {field}")


def load_and_validate() -> tuple[dict[str, Any], dict[str, Any]]:
    subject = load_canonical(SUBJECT, SUBJECT_SHA256, "subject")
    receipt = load_canonical(RECEIPT, RECEIPT_FILE_SHA256, "receipt")
    validate_receipt(receipt)
    validate_subject(subject, receipt)
    return subject, receipt


def build_local_receipt(subject: dict[str, Any], receipt: dict[str, Any]) -> dict[str, Any]:
    return {
        "schema": "data-science-pipeline/lane-m-exact-receipt-local-receipt/1",
        "verdict": "PASS_LANE_M_EXACT_RECEIPT_SOFTWARE_ONLY",
        "tests_expected": 20,
        "subject_sha256": SUBJECT_SHA256,
        "receipt_file_sha256": RECEIPT_FILE_SHA256,
        "receipt_self_hash_sha256": RECEIPT_SELF_SHA256,
        "event_universe_sha256": EVENT_UNIVERSE_SHA256,
        "review_item_commitment_sha256": REVIEW_ITEM_SHA256,
        "event_count": len(receipt["events"]),
        "contract_amount_hnl_cents": receipt["events"][0]["amount_hnl_cents"],
        "payment_amount_hnl_cents": receipt["events"][1]["amount_hnl_cents"],
        "procurement_method": subject["events"][0]["procurement_method"],
        "procurement_method_details": subject["events"][0]["procurement_method_details"],
        "bid_count_status": subject["events"][0]["bid_count_status"],
        "sefin_source_document_status": subject["events"][1]["source_document_status"],
        "relationship_state": subject["semantic_guards"]["relationship_state"],
        "exact_subject_bytes_present": True,
        "exact_operational_receipt_bytes_present": True,
        "independent_signature_created": False,
        "external_cost_usd": 0.0,
        "production_modified": False,
        "scientific_promotion_credit": 0,
        "stage08_unblocked": False,
        "next_gate": "github_oidc_sigstore_signature_then_combined_lane_e_m_arbiter_receipt",
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    subject, receipt = load_and_validate()
    result = build_local_receipt(subject, receipt)
    args.output.write_bytes(canonical_bytes(result))
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))


if __name__ == "__main__":
    main()
