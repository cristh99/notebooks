# Lane M exact receipt + OIDC/Sigstore proof

This package signs the exact owner-supplied Lane M subject and binds it to the exact 1,592-byte canonical Lane M receipt recovered from the canonical v17 capsule.

The verifier preserves the distinct `CONTRACT` and `PAYMENT` roles, equal amounts without event merging, null bid count, missing explicit SEFIN document reference, source commitments, and `CANDIDATE_REVIEW` terminal state. It rejects cross-role aggregation, empty-tenderer-to-zero inference, relationship promotion, production writes, and Stage 08 promotion.

A successful external workflow establishes exact byte integrity, GitHub Actions workflow identity, and Sigstore transparency-log inclusion. It does not establish bid count, an explicit SEFIN source document, contract-payment identity, causality, wrongdoing, production readiness, or Stage 08 readiness.
