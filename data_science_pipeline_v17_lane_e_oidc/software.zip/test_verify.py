from __future__ import annotations

import copy
import json
import tempfile
import unittest
from pathlib import Path

import verify as v

HERE = Path(__file__).resolve().parent
ENVELOPE = json.loads((HERE / "LANE_E_SIGNATURE_ENVELOPE.json").read_text())
POINTER = json.loads((HERE / "INSPECTION_RECEIPT_POINTER.json").read_text())


class LaneEEnvelopeTests(unittest.TestCase):
    def test_01_baseline_envelope_passes(self):
        v.validate_envelope(copy.deepcopy(ENVELOPE))

    def test_02_baseline_pointer_passes(self):
        v.validate_pointer(copy.deepcopy(POINTER))

    def test_03_lane_e_receipt_drift_rejected(self):
        value = copy.deepcopy(ENVELOPE)
        value["bindings"]["lane_e_canonical_receipt_sha256"] = "0" * 64
        with self.assertRaisesRegex(v.VerificationError, "binding"):
            v.validate_envelope(value)

    def test_04_event_universe_drift_rejected(self):
        value = copy.deepcopy(ENVELOPE)
        value["bindings"]["event_universe_sha256"] = "0" * 64
        with self.assertRaisesRegex(v.VerificationError, "binding"):
            v.validate_envelope(value)

    def test_05_oncae_source_drift_rejected(self):
        value = copy.deepcopy(ENVELOPE)
        value["bindings"]["oncae_raw_row_sha256"] = "0" * 64
        with self.assertRaisesRegex(v.VerificationError, "binding"):
            v.validate_envelope(value)

    def test_06_inspector_drift_rejected(self):
        value = copy.deepcopy(ENVELOPE)
        value["bindings"]["exact_field_inspector_receipt_sha256"] = "0" * 64
        with self.assertRaisesRegex(v.VerificationError, "binding"):
            v.validate_envelope(value)

    def test_07_procurement_method_drift_rejected(self):
        value = copy.deepcopy(ENVELOPE)
        value["exact_field_result"]["procurement_method"] = "direct"
        with self.assertRaisesRegex(v.VerificationError, "procurement method"):
            v.validate_envelope(value)

    def test_08_bid_count_inference_rejected(self):
        value = copy.deepcopy(ENVELOPE)
        value["exact_field_result"]["bid_count"] = 0
        with self.assertRaisesRegex(v.VerificationError, "bid count"):
            v.validate_envelope(value)

    def test_09_sefin_document_fabrication_rejected(self):
        value = copy.deepcopy(ENVELOPE)
        value["exact_field_result"]["sefin_source_document"] = "invented.pdf"
        with self.assertRaisesRegex(v.VerificationError, "SEFIN document"):
            v.validate_envelope(value)

    def test_10_lane_m_scope_violation_rejected(self):
        value = copy.deepcopy(ENVELOPE)
        value["scope"]["does_not_touch_lane_m"] = False
        with self.assertRaisesRegex(v.VerificationError, "does_not_touch_lane_m"):
            v.validate_envelope(value)

    def test_11_stage08_promotion_rejected(self):
        value = copy.deepcopy(ENVELOPE)
        value["governance"]["stage08_unblocked"] = True
        with self.assertRaisesRegex(v.VerificationError, "stage08"):
            v.validate_envelope(value)

    def test_12_nonzero_cost_rejected(self):
        value = copy.deepcopy(ENVELOPE)
        value["governance"]["external_cost_usd"] = 0.01
        with self.assertRaisesRegex(v.VerificationError, "cost"):
            v.validate_envelope(value)

    def test_13_pointer_hash_drift_rejected(self):
        value = copy.deepcopy(POINTER)
        value["exact_field_update"]["file_sha256"] = "0" * 64
        with self.assertRaisesRegex(v.VerificationError, "exact file hash"):
            v.validate_pointer(value)

    def test_14_pointer_status_drift_rejected(self):
        value = copy.deepcopy(POINTER)
        value["status"] = "EXACT_BYTES_PRESENT"
        with self.assertRaisesRegex(v.VerificationError, "pointer status"):
            v.validate_pointer(value)

    def test_15_secret_like_key_rejected(self):
        value = copy.deepcopy(ENVELOPE)
        value["governance"]["private" + "_key"] = "x"
        with self.assertRaisesRegex(v.VerificationError, "credential-like"):
            v.validate_envelope(value)

    def test_16_noncanonical_envelope_file_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            original = v.ENVELOPE_PATH
            try:
                path = Path(tmp) / "LANE_E_SIGNATURE_ENVELOPE.json"
                path.write_text(json.dumps(ENVELOPE, indent=2) + "\n")
                v.ENVELOPE_PATH = path
                with self.assertRaisesRegex(v.VerificationError, "canonical JSON"):
                    v.load_canonical(path)
            finally:
                v.ENVELOPE_PATH = original


if __name__ == "__main__":
    unittest.main(verbosity=2)
