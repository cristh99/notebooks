from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path
from typing import Any

HERE = Path(__file__).resolve().parent
ENVELOPE_PATH = HERE / "LANE_E_SIGNATURE_ENVELOPE.json"
POINTER_PATH = HERE / "INSPECTION_RECEIPT_POINTER.json"

ENVELOPE_SCHEMA = "data-science-pipeline/lane-e-independent-oidc-envelope/1"
POINTER_SCHEMA = "data-science-pipeline/exact-field-inspection-pointer/1"
EXPECTED_ENVELOPE_SHA256 = "64d86ad06aa5bf962ae8fc8fbf9c5c0a5fbbaccd8a7d4d26cc3413a56ff14aaf"
EXPECTED_POINTER_SHA256 = "c3c87cb347a7d4c1a8062204dda2fd7c7b272dce1cc54a5e2d1482d669e364b0"
EXPECTED = {
    "lane_e_canonical_receipt_sha256": "c002dc08d8536b9ba2109543a668d46d30397da7fe0968e7f850087d42c55f5b",
    "event_universe_sha256": "e53c65bd2c78979809f98051c25dd3f6239f7a4c5966578a30fcd8ecab1db88f",
    "selected_review_item_sha256": "39bd1c485c703ef371c2b57a68987f5781697197cc422c14aaa686bd9cc06f2d",
    "oncae_raw_row_sha256": "b31907dfa36e307136684d8fcd7849d4aa0d76181c4c79bdd1822151a50231e3",
    "oncae_compiled_release_sha256": "4e1b0aa5e69a065932273f187540bcef48fa01698750680d63358e039f693219",
    "oncae_archive_sha256": "43e12ce76ba1fcd3bf1240ffea4e246126bdcc2832d3d77bcb7415d8a1195c37",
    "exact_field_inspector_receipt_sha256": "7b18e89390fa93850155af058c5a951a1cfc395de0083f01d87e73f83385322e",
    "exact_field_update_file_sha256": "ce1d43a523ab67b9e5dafd22714acddac824a1621df3cbbf3b5e7653dd902158",
    "exact_field_update_self_hash": "d4a249c6b872b12ba1f5b37cc263ee8c615c39bbb70440adc12aa35eaf950602",
    "source_lineage_v2_file_sha256": "5468104139dbb5991c24262e0a5bb0b6b25e65b49f81cf525f4670e6ec57ff0b",
    "source_lineage_v2_self_hash": "43fb506e9574c1e4e2a3dbc41ec334effdac24f810866756ce8fedbac3c32526",
}
HEX64 = re.compile(r"^[0-9a-f]{64}$")
SECRET_KEY = re.compile(
    r"(^|[_-])(secret|password|private[_-]?key|credential|api[_-]?key|access[_-]?token|auth[_-]?token)($|[_-])",
    re.I,
)


class VerificationError(ValueError):
    pass


def require(value: bool, message: str) -> None:
    if not value:
        raise VerificationError(message)


def canonical_bytes(value: object) -> bytes:
    return (
        json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        + "\n"
    ).encode("utf-8")


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def sha256_file(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


def walk_no_secrets(value: Any, path: str = "$") -> None:
    if isinstance(value, dict):
        for key, child in value.items():
            require(not SECRET_KEY.search(str(key)), f"credential-like key at {path}.{key}")
            walk_no_secrets(child, f"{path}.{key}")
    elif isinstance(value, list):
        for index, child in enumerate(value):
            walk_no_secrets(child, f"{path}[{index}]")


def load_canonical(path: Path) -> dict[str, Any]:
    raw = path.read_bytes()
    value = json.loads(raw)
    require(raw == canonical_bytes(value), f"{path.name} is not canonical JSON")
    return value


def validate_envelope(value: dict[str, Any]) -> None:
    require(value.get("schema") == ENVELOPE_SCHEMA, "envelope schema mismatch")
    require(value.get("coordination_id") == "COORD-2026-08-06-PARALLEL-V2", "coordination mismatch")
    walk_no_secrets(value)

    scope = value.get("scope")
    require(isinstance(scope, dict), "scope missing")
    require(scope.get("lane") == "Lane E — entity/provider", "lane mismatch")
    require(scope.get("canonical_lane_e_pr") == 140, "Lane E PR mismatch")
    require(scope.get("canonical_lane_v_pr") == 144, "Lane V PR mismatch")
    require(scope.get("canonical_arbiter_pr") == 138, "arbiter PR mismatch")
    for field in (
        "exclusive_scope",
        "does_not_touch_lane_m",
        "does_not_modify_normalization",
        "does_not_modify_thresholds",
        "does_not_modify_canonical_transport",
    ):
        require(scope.get(field) is True, f"{field} must be true")

    bindings = value.get("bindings")
    require(isinstance(bindings, dict), "bindings missing")
    require(bindings == EXPECTED, "binding set mismatch")
    require(all(HEX64.fullmatch(v) for v in bindings.values()), "invalid binding digest")

    result = value.get("exact_field_result")
    require(isinstance(result, dict), "exact field result missing")
    require(result.get("procurement_method") == "open", "procurement method mismatch")
    require(result.get("procurement_method_details") == "Convenio Marco", "method details mismatch")
    require(result.get("bid_count") is None, "bid count must remain null")
    require(result.get("bid_count_status") == "ABSTAIN_MISSING_EXPLICIT_FIELD", "bid-count abstention mismatch")
    require(result.get("sefin_source_document") is None, "SEFIN document must remain null")
    require(
        result.get("sefin_source_document_status")
        == "ABSTAIN_MISSING_EXPLICIT_DOCUMENT_REF",
        "SEFIN document abstention mismatch",
    )

    trust = value.get("trust_contract")
    require(isinstance(trust, dict), "trust contract missing")
    require(trust.get("mechanism") == "github_actions_oidc_sigstore_cosign_keyless", "trust mechanism mismatch")
    require(trust.get("repository") == "cristh99/notebooks", "repository mismatch")
    require(trust.get("repository_id") == "616013328", "repository id mismatch")
    require(trust.get("repository_owner_id") == "87334928", "owner id mismatch")
    require(trust.get("repository_visibility") == "public", "visibility mismatch")
    require(
        trust.get("workflow_path")
        == ".github/workflows/data-science-v17-lane-e-oidc.yml",
        "workflow path mismatch",
    )
    require(
        trust.get("branch")
        == "agent/data-science-v17-lane-e-oidc-signature-v1",
        "branch mismatch",
    )
    require(trust.get("oidc_issuer") == "https://token.actions.githubusercontent.com", "issuer mismatch")
    require(trust.get("oidc_audience") == "sigstore", "audience mismatch")
    require(trust.get("cosign_version") == "3.0.6", "Cosign version mismatch")
    require(
        trust.get("cosign_linux_amd64_sha256")
        == "c956e5dfcac53d52bcf058360d579472f0c1d2d9b69f55209e256fe7783f4c74",
        "Cosign digest mismatch",
    )
    require(trust.get("sigstore_bundle_required") is True, "bundle required")
    require(trust.get("transparency_log_inclusion_required") is True, "tlog required")

    governance = value.get("governance")
    require(isinstance(governance, dict), "governance missing")
    require(governance.get("external_cost_usd") == 0.0, "external cost must be zero")
    require(governance.get("scientific_promotion_credit") == 0, "promotion credit must be zero")
    for field in (
        "production_modified",
        "mass_processing_authorized",
        "merge_authorized",
        "stage08_unblocked",
    ):
        require(governance.get(field) is False, f"{field} must be false")

    boundary = value.get("claim_boundary")
    require(isinstance(boundary, dict), "claim boundary missing")
    require(
        "truth of unmounted exact-field receipt bytes"
        in boundary.get("does_not_establish", []),
        "unmounted-byte boundary missing",
    )
    require(
        "Lane M validity" in boundary.get("does_not_establish", []),
        "Lane M boundary missing",
    )


def validate_pointer(value: dict[str, Any]) -> None:
    require(value.get("schema") == POINTER_SCHEMA, "pointer schema mismatch")
    require(value.get("coordination_id") == "COORD-2026-08-06-PARALLEL-V2", "pointer coordination mismatch")
    require(value.get("canonical_pr") == 144, "pointer PR mismatch")
    require(value.get("source_message_id") == 102, "pointer message mismatch")
    require(
        value.get("status") == "EXACT_BYTES_NOT_MOUNTED_IN_SIGNER_RUNTIME",
        "pointer status mismatch",
    )
    require(
        value.get("claim")
        == "This pointer preserves immutable commitments only and is not a substitute for the exact receipt bytes.",
        "pointer claim mismatch",
    )
    exact = value.get("exact_field_update")
    lineage = value.get("source_lineage_v2")
    bundle = value.get("bundle")
    require(isinstance(exact, dict) and isinstance(lineage, dict) and isinstance(bundle, dict), "pointer sections missing")
    require(exact.get("expected_filename") == "LANE_V17_EXACT_FIELD_INSPECTION_RECEIPT.json", "exact filename mismatch")
    require(exact.get("file_sha256") == EXPECTED["exact_field_update_file_sha256"], "exact file hash mismatch")
    require(exact.get("self_hash") == EXPECTED["exact_field_update_self_hash"], "exact self-hash mismatch")
    require(lineage.get("expected_filename") == "SOURCE_LINEAGE_DISCOVERY_V2.json", "lineage filename mismatch")
    require(lineage.get("file_sha256") == EXPECTED["source_lineage_v2_file_sha256"], "lineage file hash mismatch")
    require(lineage.get("self_hash") == EXPECTED["source_lineage_v2_self_hash"], "lineage self-hash mismatch")
    require(bundle.get("expected_filename") == "DATA_SCIENCE_V17_OPERATIONAL_FIELD_UPDATE.zip", "bundle filename mismatch")
    require(bundle.get("sha256") == "2a9e6b24166b40849c73f41e2bcc10d0d601159b5507384f4152c11f9a58d7fc", "bundle hash mismatch")
    require(bundle.get("manifest_self_hash") == "b9dfabfa039bb3d77a6a039f8e32472fb08e66c0f92321e7b2fdca0908bef62f", "manifest self-hash mismatch")
    require(value.get("stage08_unblocked") is False, "pointer cannot unblock Stage 08")
    require(value.get("production_modified") is False, "pointer cannot modify production")
    require(value.get("external_cost_usd") == 0.0, "pointer cost must be zero")
    walk_no_secrets(value)


def verify_static(output: Path) -> dict[str, Any]:
    envelope = load_canonical(ENVELOPE_PATH)
    pointer = load_canonical(POINTER_PATH)
    validate_envelope(envelope)
    validate_pointer(pointer)
    require(sha256_file(ENVELOPE_PATH) == EXPECTED_ENVELOPE_SHA256, "envelope SHA-256 mismatch")
    require(sha256_file(POINTER_PATH) == EXPECTED_POINTER_SHA256, "pointer SHA-256 mismatch")
    receipt = {
        "schema": "data-science-pipeline/lane-e-independent-local-receipt/1",
        "verdict": "PASS_LANE_E_HASH_BINDING_SOFTWARE_ONLY",
        "envelope_sha256": EXPECTED_ENVELOPE_SHA256,
        "pointer_sha256": EXPECTED_POINTER_SHA256,
        "tests_expected": 16,
        "exact_receipt_bytes_present": False,
        "independent_signature_created": False,
        "external_cost_usd": 0.0,
        "production_modified": False,
        "scientific_promotion_credit": 0,
        "stage08_unblocked": False,
        "next_gate": "github_oidc_sigstore_signature_then_exact_receipt_byte_attachment",
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_bytes(canonical_bytes(receipt))
    return receipt


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    receipt = verify_static(args.output)
    print(json.dumps(receipt, ensure_ascii=False, sort_keys=True))


if __name__ == "__main__":
    main()
