Set Warnings "-notation-overridden".
From Coq Require Import Lia.
From LF Require Import Tactics Logic IndProp Rel.

Module BlindProof.

Module Target07.
Theorem LF_BLIND_07_Perm3_NotIn : forall (X : Type) (x : X) (l1 l2 : list X),
  Perm3 l1 l2 -> ~ In x l1 -> ~ In x l2.
Proof.
  intros X x l1 l2 Hperm.
  induction Hperm as
      [a b c
      |a b c
      |l1 l2 l3 H12 IH12 H23 IH23].
  - simpl. intros Hnot Hin.
    apply Hnot.
    destruct Hin as [H | [H | [H | H]]].
    + right. left. exact H.
    + left. exact H.
    + right. right. left. exact H.
    + contradiction.
  - simpl. intros Hnot Hin.
    apply Hnot.
    destruct Hin as [H | [H | [H | H]]].
    + left. exact H.
    + right. right. left. exact H.
    + right. left. exact H.
    + contradiction.
  - intros Hnot.
    apply IH23. apply IH12. exact Hnot.
Qed.
End Target07.

Module Target08.
Example LF_BLIND_08_discriminate_ex3 :
  forall (X : Type) (x y z : X) (l j : list X),
    x :: y :: l = [] -> x = z.
Proof.
  intros X x y z l j H.
  discriminate H.
Qed.
End Target08.

Module Target09.
Lemma LF_BLIND_09_mult_is_O :
  forall n m, n * m = 0 -> n = 0 \/ m = 0.
Proof.
  intros n m H.
  destruct n as [|n].
  - left. reflexivity.
  - right. destruct m as [|m].
    + reflexivity.
    + simpl in H. discriminate H.
Qed.
End Target09.

Module Target10.
Theorem LF_BLIND_10_le_not_symmetric :
  ~ (symmetric le).
Proof.
  unfold not, symmetric.
  intro Hsym.
  assert (H01 : 0 <= 1).
  { apply le_S. apply le_n. }
  pose proof (Hsym 0 1 H01) as H10.
  inversion H10.
Qed.
End Target10.

Module Target11.
Import Pumping.
Lemma LF_BLIND_11_weak_pumping_union_l : forall T (s1 : list T) (re1 re2 : reg_exp T),
  s1 =~ re1 ->
  (pumping_constant re1 <= length s1 ->
    exists s2 s3 s4 : list T,
      s1 = s2 ++ s3 ++ s4 /\
      s3 <> [] /\
      (forall m : nat, s2 ++ napp m s3 ++ s4 =~ re1)) ->
  pumping_constant (Union re1 re2) <= length s1 ->
  exists s0 s2 s3 : list T,
    s1 = s0 ++ s2 ++ s3 /\
    s2 <> [] /\
    (forall m : nat, s0 ++ napp m s2 ++ s3 =~ Union re1 re2).
Proof.
  intros T s1 re1 re2 Hmatch IH Hlen.
  simpl in Hlen.
  assert (Hpc : pumping_constant re1 <= length s1) by lia.
  destruct (IH Hpc) as [s0 [s2 [s3 [Heq [Hne Hall]]]]].
  exists s0, s2, s3.
  split. exact Heq.
  split. exact Hne.
  intros m. apply MUnionL. apply Hall.
Qed.
End Target11.

Module Target12.
Theorem LF_BLIND_12_filter_exercise : forall (X : Type) (test : X -> bool)
  (x : X) (l lf : list X),
  filter test l = x :: lf ->
  test x = true.
Proof.
  intros X test x l lf H.
  destruct l as [|h t].
  - discriminate H.
  - simpl in H.
    destruct (test h) eqn:Htest.
    + inversion H. subst. exact Htest.
    + discriminate H.
Qed.
End Target12.

End BlindProof.

Print Assumptions BlindProof.Target07.LF_BLIND_07_Perm3_NotIn.
Print Assumptions BlindProof.Target08.LF_BLIND_08_discriminate_ex3.
Print Assumptions BlindProof.Target09.LF_BLIND_09_mult_is_O.
Print Assumptions BlindProof.Target10.LF_BLIND_10_le_not_symmetric.
Print Assumptions BlindProof.Target11.LF_BLIND_11_weak_pumping_union_l.
Print Assumptions BlindProof.Target12.LF_BLIND_12_filter_exercise.
