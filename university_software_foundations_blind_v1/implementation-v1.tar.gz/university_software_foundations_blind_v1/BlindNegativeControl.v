From LF Require Import Basics.

Theorem blind_false_mutation : 2 + 2 = 5.
Proof. reflexivity. Qed.
