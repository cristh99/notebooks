Set Warnings "-notation-overridden".
From LF Require Import Basics Lists Poly.

Module BlindEarly.

Module Target01.
Import NatList.
Theorem LF_BLIND_01_fst_swap_is_snd : forall (p : natprod),
  fst (swap_pair p) = snd p.
Proof.
  intros [n m]. reflexivity.
Qed.
End Target01.

Module Target02.
Import LateDays.
Theorem LF_BLIND_02_letter_comparison_Eq :
  forall l, letter_comparison l l = Eq.
Proof.
  intros l. destruct l; reflexivity.
Qed.
End Target02.

Module Target03.
Definition scc (n : Church.cnat) : Church.cnat :=
  fun (X : Type) (f : X -> X) (x : X) => f (n X f x).
Example LF_BLIND_03_scc_1 : scc Church.zero = Church.one.
Proof. reflexivity. Qed.
End Target03.

Module Target04.
Definition lower_grade (g : LateDays.grade) : LateDays.grade :=
  match g with
  | LateDays.Grade l LateDays.Plus => LateDays.Grade l LateDays.Natural
  | LateDays.Grade l LateDays.Natural => LateDays.Grade l LateDays.Minus
  | LateDays.Grade l LateDays.Minus =>
      match l with
      | LateDays.F => LateDays.Grade LateDays.F LateDays.Minus
      | _ => LateDays.Grade (LateDays.lower_letter l) LateDays.Plus
      end
  end.

Definition apply_late_policy (late_days : nat) (g : LateDays.grade) : LateDays.grade :=
  if late_days <? 9 then g
  else if late_days <? 17 then lower_grade g
  else if late_days <? 21 then lower_grade (lower_grade g)
  else lower_grade (lower_grade (lower_grade g)).

Theorem LF_BLIND_04_no_penalty_for_mostly_on_time :
  forall (late_days : nat) (g : LateDays.grade),
    late_days <? 9 = true ->
    apply_late_policy late_days g = g.
Proof.
  intros late_days g Hlt.
  unfold apply_late_policy.
  rewrite Hlt. reflexivity.
Qed.
End Target04.

Module Target05.
Theorem LF_BLIND_05_involution_injective : forall (f : nat -> nat),
  (forall n : nat, n = f (f n)) ->
  forall n1 n2 : nat, f n1 = f n2 -> n1 = n2.
Proof.
  intros f Hinv n1 n2 Heq.
  rewrite (Hinv n1), (Hinv n2), Heq.
  reflexivity.
Qed.
End Target05.

Module Target06.
Definition plus (n m : Church.cnat) : Church.cnat :=
  fun (X : Type) (f : X -> X) (x : X) => n X f (m X f x).
Example LF_BLIND_06_plus_1 : plus Church.zero Church.one = Church.one.
Proof. reflexivity. Qed.
End Target06.

End BlindEarly.

Print Assumptions BlindEarly.Target01.LF_BLIND_01_fst_swap_is_snd.
Print Assumptions BlindEarly.Target02.LF_BLIND_02_letter_comparison_Eq.
Print Assumptions BlindEarly.Target03.LF_BLIND_03_scc_1.
Print Assumptions BlindEarly.Target04.LF_BLIND_04_no_penalty_for_mostly_on_time.
Print Assumptions BlindEarly.Target05.LF_BLIND_05_involution_injective.
Print Assumptions BlindEarly.Target06.LF_BLIND_06_plus_1.
