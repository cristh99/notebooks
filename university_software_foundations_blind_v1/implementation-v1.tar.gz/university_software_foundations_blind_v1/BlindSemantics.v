Set Warnings "-notation-overridden".
From LF Require Import Imp.

Module BlindSemantics.

Module Target13.
Example LF_BLIND_13_ceval_example2:
  empty_st =[
    X := 0;
    Y := 1;
    Z := 2
  ]=> (Z !-> 2 ; Y !-> 1 ; X !-> 0).
Proof.
  apply E_Seq with (X !-> 0).
  - apply E_Asgn. reflexivity.
  - apply E_Seq with (Y !-> 1 ; X !-> 0).
    + apply E_Asgn. reflexivity.
    + apply E_Asgn. reflexivity.
Qed.
End Target13.

Module BlindBreakImp.

Inductive com : Type :=
  | BSkip
  | BBreak
  | BAsgn (x : string) (a : aexp)
  | BSeq (c1 c2 : com)
  | BIf (b : bexp) (c1 c2 : com)
  | BWhile (b : bexp) (c : com).

Inductive result : Type :=
  | SContinue
  | SBreak.

Inductive ceval : com -> state -> result -> state -> Prop :=
  | BE_Skip : forall st,
      ceval BSkip st SContinue st
  | BE_Break : forall st,
      ceval BBreak st SBreak st
  | BE_Asgn : forall st a n x,
      aeval st a = n ->
      ceval (BAsgn x a) st SContinue (x !-> n ; st)
  | BE_SeqBreak : forall c1 c2 st st',
      ceval c1 st SBreak st' ->
      ceval (BSeq c1 c2) st SBreak st'
  | BE_SeqContinue : forall c1 c2 st st' st'' s,
      ceval c1 st SContinue st' ->
      ceval c2 st' s st'' ->
      ceval (BSeq c1 c2) st s st''
  | BE_IfTrue : forall st st' b c1 c2 s,
      beval st b = true ->
      ceval c1 st s st' ->
      ceval (BIf b c1 c2) st s st'
  | BE_IfFalse : forall st st' b c1 c2 s,
      beval st b = false ->
      ceval c2 st s st' ->
      ceval (BIf b c1 c2) st s st'
  | BE_WhileFalse : forall b st c,
      beval st b = false ->
      ceval (BWhile b c) st SContinue st
  | BE_WhileTrueContinue : forall st st' st'' b c,
      beval st b = true ->
      ceval c st SContinue st' ->
      ceval (BWhile b c) st' SContinue st'' ->
      ceval (BWhile b c) st SContinue st''
  | BE_WhileTrueBreak : forall st st' b c,
      beval st b = true ->
      ceval c st SBreak st' ->
      ceval (BWhile b c) st SContinue st'.

Theorem LF_BLIND_14_while_break_true : forall b c st st',
  ceval (BWhile b c) st SContinue st' ->
  beval st' b = true ->
  exists st'', ceval c st'' SBreak st'.
Proof.
  fix IH 5.
  intros b c st st' Hce Hfinal.
  inversion Hce; subst.
  - congruence.
  - eapply IH; eauto.
  - eauto.
Qed.

Ltac use_matching_ih :=
  match goal with
  | IH : forall (st2 : state) (s2 : result),
           ceval ?c ?st s2 st2 ->
           ?st1 = st2 /\ ?s1 = s2,
    H : ceval ?c ?st ?s2 ?st2 |- _ =>
      first [ constr_eq st1 st2; constr_eq s1 s2; fail 1
            | let E := fresh "E" in
              pose proof (IH st2 s2 H) as E;
              clear IH;
              destruct E as [? ?]; subst ]
  end.

Theorem LF_BLIND_15_ceval_deterministic : forall (c : com) st st1 st2 s1 s2,
  ceval c st s1 st1 ->
  ceval c st s2 st2 ->
  st1 = st2 /\ s1 = s2.
Proof.
  intros c st st1 st2 s1 s2 H1.
  revert st2 s2.
  induction H1; intros st2 s2 H2; inversion H2; subst.
  all: repeat use_matching_ih.
  all: try congruence.
  all: split; congruence.
Qed.

End BlindBreakImp.
End BlindSemantics.

Print Assumptions BlindSemantics.Target13.LF_BLIND_13_ceval_example2.
Print Assumptions BlindSemantics.BlindBreakImp.LF_BLIND_14_while_break_true.
Print Assumptions BlindSemantics.BlindBreakImp.LF_BLIND_15_ceval_deterministic.
