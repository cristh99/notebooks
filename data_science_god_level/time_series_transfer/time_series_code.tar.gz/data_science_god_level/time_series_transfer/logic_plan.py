from __future__ import annotations

import json
from fractions import Fraction
from pathlib import Path

from logic_power_v10.active_discovery import ActiveDiscoveryProblem, Experiment
from logic_power_v10.certificate import build_certificate, verify_certificate


def _experiment(name: str, cost: int, observations: dict[str, str]) -> Experiment:
    return Experiment(name=name, cost=Fraction(cost), observations=observations)


def main() -> None:
    hypotheses = (
        "prior_benchmark_specialist",
        "static_supervised_modeler",
        "generic_temporal_forecaster",
        "broad_data_science_capability",
    )
    property_map = {
        "prior_benchmark_specialist": False,
        "static_supervised_modeler": False,
        "generic_temporal_forecaster": True,
        "broad_data_science_capability": True,
    }
    experiments = (
        _experiment(
            "repeat_supervised_tabular_transfer",
            1,
            {hypothesis: "PASS" for hypothesis in hypotheses},
        ),
        _experiment(
            "retune_exposed_anomaly_suite",
            1,
            {hypothesis: "POST_HOC_INVALID" for hypothesis in hypotheses},
        ),
        _experiment(
            "cpu_rolling_origin_multifrequency_forecast_transfer",
            5,
            {
                "prior_benchmark_specialist": "FAIL",
                "static_supervised_modeler": "FAIL",
                "generic_temporal_forecaster": "PASS",
                "broad_data_science_capability": "PASS",
            },
        ),
        _experiment(
            "h100_time_series_foundation_model",
            45,
            {
                "prior_benchmark_specialist": "FAIL",
                "static_supervised_modeler": "FAIL",
                "generic_temporal_forecaster": "PASS",
                "broad_data_science_capability": "PASS",
            },
        ),
        _experiment(
            "prospective_operational_forecasting_deployment",
            100,
            {
                "prior_benchmark_specialist": "FAIL",
                "static_supervised_modeler": "FAIL",
                "generic_temporal_forecaster": "PASS",
                "broad_data_science_capability": "PASS",
            },
        ),
    )
    problem = ActiveDiscoveryProblem(
        hypotheses,
        property_map,
        experiments,
        {hypothesis: Fraction(1, 4) for hypothesis in hypotheses},
    )
    certificate = build_certificate(problem, "next-gate-after-unsupervised-anomaly-fail")
    errors = verify_certificate(certificate)
    if errors:
        raise SystemExit(f"Logic Power v10 replay failed: {errors}")
    analysis = certificate["payload"]["analysis"]
    selected = "cpu_rolling_origin_multifrequency_forecast_transfer"
    if not analysis["policy"]["exact"]:
        raise SystemExit("no exact separating policy")
    if analysis["policy"]["tree"]["experiment"] != selected:
        raise SystemExit(f"unexpected experiment: {analysis['policy']['tree']}")
    if analysis["fixed_basis"] != [selected]:
        raise SystemExit(f"unexpected basis: {analysis['fixed_basis']}")

    receipt = {
        "schema": "data-science-god-level/time-series-transfer-logic-plan/1",
        "logic_power_v10_private_head": "ba10d0edc7eb20d499d0481fda2537e782b6efb2",
        "problem_solver_role": "minimum admissible independent portfolio under validity, information gain, cost, and zero paid compute",
        "consensus_evidence": {
            "forecast_evaluation": "rolling-origin and valid time-aware partitions prevent spurious forecasting conclusions",
            "forecast_combinations": "combinations reduce the risk of selecting a single unstable best forecaster",
            "fforma": "time-series features can guide forecast combinations on unseen series",
        },
        "prior_evidence": {
            "supervised_tabular_transfer": "OFFICIAL_PASS_6_OF_6",
            "unsupervised_anomaly_transfer": "OFFICIAL_FAIL_NO_CREDIT",
            "realcause_twins": "OFFICIAL_FAIL_ABSOLUTE_PEHE",
        },
        "selected_experiment": selected,
        "selection_reason": "lowest-cost fresh external gate separating prospective temporal forecasting from static supervised or prior-benchmark specialization",
        "rejected_experiments": {
            "repeat_supervised_tabular_transfer": "non-separating repetition",
            "retune_exposed_anomaly_suite": "post-hoc and inadmissible",
            "h100_time_series_foundation_model": "separating but dominated by paid GPU cost",
            "prospective_operational_forecasting_deployment": "stronger external validity but unavailable and dominated now",
        },
        "public_roles": ["p01", "p02", "p03", "p04", "p05", "p06"],
        "official_roles": ["o01", "o02", "o03", "o04", "o05", "o06"],
        "candidate_future_access": False,
        "official_truth_access_before_freeze": False,
        "certificate": certificate,
    }
    Path("logic-plan-receipt.json").write_text(
        json.dumps(receipt, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(receipt, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
