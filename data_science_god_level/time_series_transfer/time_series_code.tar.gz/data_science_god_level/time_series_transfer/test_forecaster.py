from __future__ import annotations

import unittest
import numpy as np

from forecaster import forecast_series


class ForecastTests(unittest.TestCase):
    def test_linear_trend(self):
        y = 5.0 + 0.7 * np.arange(120)
        result = forecast_series(y, 12, None)
        truth = 5.0 + 0.7 * np.arange(120, 132)
        self.assertLess(np.mean(np.abs(result.point - truth)), 2.0)
        self.assertTrue(result.diagnostics["finite"])

    def test_seasonal_trend(self):
        t = np.arange(180)
        y = 20.0 + 0.05 * t + 4.0 * np.sin(2 * np.pi * t / 12)
        result = forecast_series(y, 18, [12])
        truth_t = np.arange(180, 198)
        truth = 20.0 + 0.05 * truth_t + 4.0 * np.sin(2 * np.pi * truth_t / 12)
        self.assertLess(np.mean(np.abs(result.point - truth)), 1.5)

    def test_missing_values_and_intervals(self):
        rng = np.random.default_rng(7)
        y = np.cumsum(rng.normal(size=150)) + 30
        y[12] = np.nan
        result = forecast_series(y, 10, None)
        self.assertEqual(result.point.shape, (10,))
        self.assertTrue(np.all(result.lower <= result.point))
        self.assertTrue(np.all(result.point <= result.upper))

    def test_rejects_short_series(self):
        with self.assertRaises(ValueError):
            forecast_series(np.arange(10), 3)


if __name__ == "__main__":
    unittest.main()
