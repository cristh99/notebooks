from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Sequence

import numpy as np
from scipy.special import softmax
from sklearn.linear_model import Ridge
from statsmodels.tsa.holtwinters import ExponentialSmoothing, Holt, SimpleExpSmoothing


@dataclass(frozen=True)
class ForecastResult:
    point: np.ndarray
    lower: np.ndarray
    upper: np.ndarray
    diagnostics: dict[str, Any]


def _clean_series(values: np.ndarray) -> np.ndarray:
    y = np.asarray(values, dtype=float).reshape(-1)
    if y.size < 24:
        raise ValueError("at least 24 observations are required")
    finite = np.isfinite(y)
    if not finite.any():
        raise ValueError("series has no finite values")
    if not finite.all():
        idx = np.arange(y.size)
        y = np.interp(idx, idx[finite], y[finite])
    return y


def _periods(periods: Sequence[int] | int | None, n: int) -> tuple[int, ...]:
    if periods is None:
        return ()
    if isinstance(periods, (int, np.integer)):
        periods = [int(periods)]
    clean = sorted({int(p) for p in periods if int(p) >= 2 and int(p) < n // 2})
    return tuple(clean)


def _repeat_cycle(cycle: np.ndarray, horizon: int) -> np.ndarray:
    return np.resize(np.asarray(cycle, dtype=float), horizon)


def _naive(y: np.ndarray, h: int, _: tuple[int, ...]) -> np.ndarray:
    return np.full(h, y[-1], dtype=float)


def _drift(y: np.ndarray, h: int, _: tuple[int, ...]) -> np.ndarray:
    window = min(len(y), max(20, len(y) // 2))
    slope = (y[-1] - y[-window]) / max(window - 1, 1)
    return y[-1] + slope * np.arange(1, h + 1)


def _recent_mean(y: np.ndarray, h: int, periods: tuple[int, ...]) -> np.ndarray:
    window = min(len(y), max(8, min(periods) if periods else int(np.sqrt(len(y)))))
    return np.full(h, float(np.mean(y[-window:])), dtype=float)


def _linear_trend(y: np.ndarray, h: int, periods: tuple[int, ...]) -> np.ndarray:
    window = min(len(y), max(30, 4 * min(periods) if periods else len(y) // 2))
    values = y[-window:]
    x = np.linspace(-1.0, 0.0, window)
    future = np.arange(1, h + 1, dtype=float) / max(window - 1, 1)
    coef = np.polyfit(x, values, deg=1)
    return np.polyval(coef, future)


def _simple_exp(y: np.ndarray, h: int, _: tuple[int, ...]) -> np.ndarray:
    fit = SimpleExpSmoothing(y, initialization_method="estimated").fit(optimized=True)
    return np.asarray(fit.forecast(h), dtype=float)


def _holt(y: np.ndarray, h: int, _: tuple[int, ...]) -> np.ndarray:
    fit = Holt(y, damped_trend=True, initialization_method="estimated").fit(optimized=True)
    return np.asarray(fit.forecast(h), dtype=float)


def _seasonal_naive_factory(period: int) -> Callable[[np.ndarray, int, tuple[int, ...]], np.ndarray]:
    def forecast(y: np.ndarray, h: int, _: tuple[int, ...]) -> np.ndarray:
        return _repeat_cycle(y[-period:], h)
    return forecast


def _seasonal_average_factory(period: int) -> Callable[[np.ndarray, int, tuple[int, ...]], np.ndarray]:
    def forecast(y: np.ndarray, h: int, _: tuple[int, ...]) -> np.ndarray:
        cycles = min(5, len(y) // period)
        matrix = y[-cycles * period:].reshape(cycles, period)
        weights = np.arange(1, cycles + 1, dtype=float)
        cycle = np.average(matrix, axis=0, weights=weights)
        return _repeat_cycle(cycle, h)
    return forecast


def _seasonal_drift_factory(period: int) -> Callable[[np.ndarray, int, tuple[int, ...]], np.ndarray]:
    def forecast(y: np.ndarray, h: int, _: tuple[int, ...]) -> np.ndarray:
        base = _repeat_cycle(y[-period:], h)
        if len(y) < 2 * period:
            return base
        delta = float(np.median(y[-period:] - y[-2 * period:-period]))
        cycle_index = 1.0 + np.arange(h, dtype=float) // period
        return base + delta * cycle_index
    return forecast


def _ets_factory(period: int, multiplicative: bool) -> Callable[[np.ndarray, int, tuple[int, ...]], np.ndarray]:
    def forecast(y: np.ndarray, h: int, _: tuple[int, ...]) -> np.ndarray:
        if len(y) < 3 * period:
            raise ValueError("insufficient seasonal cycles")
        seasonal = "mul" if multiplicative else "add"
        if multiplicative and np.min(y) <= 0:
            raise ValueError("multiplicative ETS requires positive values")
        fit = ExponentialSmoothing(
            y,
            trend="add",
            damped_trend=True,
            seasonal=seasonal,
            seasonal_periods=period,
            initialization_method="estimated",
        ).fit(optimized=True, use_brute=False)
        return np.asarray(fit.forecast(h), dtype=float)
    return forecast


def _fourier_ridge(y: np.ndarray, h: int, periods: tuple[int, ...]) -> np.ndarray:
    n = len(y)
    use_periods = [p for p in periods if p <= n // 2]
    window = min(n, max(96, 6 * max(use_periods) if use_periods else n))
    values = y[-window:]
    t = np.arange(window, dtype=float)
    future_t = np.arange(window, window + h, dtype=float)

    def features(time: np.ndarray) -> np.ndarray:
        scaled = time / max(window - 1, 1)
        columns = [np.ones_like(scaled), scaled, scaled * scaled]
        for period in use_periods:
            harmonics = min(5, max(1, period // 4))
            for k in range(1, harmonics + 1):
                angle = 2.0 * np.pi * k * time / period
                columns.extend([np.sin(angle), np.cos(angle)])
        return np.column_stack(columns)

    model = Ridge(alpha=max(1e-4, 0.01 * np.var(values)))
    model.fit(features(t), values)
    return np.asarray(model.predict(features(future_t)), dtype=float)


def _ridge_ar(y: np.ndarray, h: int, periods: tuple[int, ...]) -> np.ndarray:
    n = len(y)
    base_lags = list(range(1, min(12, max(3, n // 15)) + 1))
    extra = []
    for p in periods:
        extra.extend([p, max(1, p - 1), p + 1])
        if p >= 4:
            extra.append(p // 2)
    lags = sorted({lag for lag in base_lags + extra if 1 <= lag < n // 3})
    if not lags:
        return _drift(y, h, periods)
    max_lag = max(lags)
    rows = []
    target = []
    for i in range(max_lag, n):
        row = [y[i - lag] for lag in lags]
        row.extend([i / n, (i / n) ** 2])
        for p in periods:
            if p <= n // 2:
                row.extend([np.sin(2 * np.pi * i / p), np.cos(2 * np.pi * i / p)])
        rows.append(row)
        target.append(y[i])
    X = np.asarray(rows, dtype=float)
    target_arr = np.asarray(target, dtype=float)
    scale = max(float(np.std(target_arr)), 1e-8)
    model = Ridge(alpha=0.25 * scale)
    model.fit(X, target_arr)
    history = list(map(float, y))
    output = []
    for step in range(1, h + 1):
        i = n + step - 1
        row = [history[i - lag] for lag in lags]
        row.extend([i / n, (i / n) ** 2])
        for p in periods:
            if p <= n // 2:
                row.extend([np.sin(2 * np.pi * i / p), np.cos(2 * np.pi * i / p)])
        value = float(model.predict(np.asarray(row, dtype=float).reshape(1, -1))[0])
        if not np.isfinite(value):
            value = history[-1]
        history.append(value)
        output.append(value)
    return np.asarray(output, dtype=float)


def _log_wrapper(fn: Callable[[np.ndarray, int, tuple[int, ...]], np.ndarray]) -> Callable[[np.ndarray, int, tuple[int, ...]], np.ndarray]:
    def forecast(y: np.ndarray, h: int, periods: tuple[int, ...]) -> np.ndarray:
        if np.min(y) <= 0:
            raise ValueError("log model requires positive values")
        shift = max(0.0, 1e-6 - float(np.min(y)))
        pred = fn(np.log1p(y + shift), h, periods)
        return np.expm1(pred) - shift
    return forecast


def _model_pool(y: np.ndarray, periods: tuple[int, ...]) -> dict[str, Callable[[np.ndarray, int, tuple[int, ...]], np.ndarray]]:
    models: dict[str, Callable[[np.ndarray, int, tuple[int, ...]], np.ndarray]] = {
        "naive": _naive,
        "drift": _drift,
        "recent_mean": _recent_mean,
        "linear_trend": _linear_trend,
        "simple_exp": _simple_exp,
        "holt_damped": _holt,
        "fourier_ridge": _fourier_ridge,
        "ridge_ar": _ridge_ar,
    }
    for p in periods:
        models[f"seasonal_naive_{p}"] = _seasonal_naive_factory(p)
        models[f"seasonal_average_{p}"] = _seasonal_average_factory(p)
        models[f"seasonal_drift_{p}"] = _seasonal_drift_factory(p)
        if p <= 60 and len(y) >= 3 * p:
            models[f"ets_add_{p}"] = _ets_factory(p, False)
            if np.min(y) > 0:
                models[f"ets_mul_{p}"] = _ets_factory(p, True)
    if np.min(y) > 0 and np.max(y) / max(np.min(y), 1e-12) > 1.5:
        models["log_holt_damped"] = _log_wrapper(_holt)
        models["log_fourier_ridge"] = _log_wrapper(_fourier_ridge)
        models["log_ridge_ar"] = _log_wrapper(_ridge_ar)
    return models


def _smape(actual: np.ndarray, pred: np.ndarray) -> float:
    denom = np.abs(actual) + np.abs(pred)
    return float(200.0 * np.mean(np.abs(actual - pred) / np.maximum(denom, 1e-8)))


def _scale(train: np.ndarray, periods: tuple[int, ...]) -> float:
    p = periods[0] if periods and len(train) > periods[0] else 1
    diffs = np.abs(train[p:] - train[:-p])
    scale = float(np.mean(diffs)) if diffs.size else float(np.mean(np.abs(np.diff(train))))
    if not np.isfinite(scale) or scale < 1e-8:
        scale = max(float(np.std(train)), 1.0)
    return scale


def _mase(actual: np.ndarray, pred: np.ndarray, train: np.ndarray, periods: tuple[int, ...]) -> float:
    return float(np.mean(np.abs(actual - pred)) / _scale(train, periods))


def _validation_origins(n: int, horizon: int, periods: tuple[int, ...]) -> list[int]:
    max_p = max(periods, default=1)
    val_h = min(horizon, max(4, min(24, horizon)))
    min_train = max(30, 2 * max_p + val_h, 4 * val_h)
    latest = n - val_h
    if latest <= min_train:
        min_train = max(24, n - 3 * val_h)
    candidates = [latest - 3 * val_h, latest - 2 * val_h, latest - val_h, latest]
    origins = sorted({o for o in candidates if o >= min_train and o + val_h <= n})
    if len(origins) < 2:
        origins = sorted({max(24, n - 2 * val_h), max(24, n - val_h)})
    return origins


def forecast_series(
    values: np.ndarray,
    horizon: int,
    seasonal_periods: Sequence[int] | int | None = None,
    *,
    interval_level: float = 0.90,
) -> ForecastResult:
    y = _clean_series(values)
    if horizon < 1:
        raise ValueError("horizon must be positive")
    periods = _periods(seasonal_periods, len(y))
    models = _model_pool(y, periods)
    origins = _validation_origins(len(y), horizon, periods)
    val_h = min(horizon, max(4, min(24, horizon)))

    per_model_losses: dict[str, list[float]] = {name: [] for name in models}
    pooled_errors: dict[str, list[np.ndarray]] = {name: [] for name in models}
    successful: set[str] = set()

    for origin in origins:
        train = y[:origin]
        actual = y[origin:origin + val_h]
        baseline = _seasonal_naive_factory(periods[0])(train, val_h, periods) if periods and len(train) >= periods[0] else _naive(train, val_h, periods)
        base_mase = max(_mase(actual, baseline, train, periods), 1e-4)
        base_smape = max(_smape(actual, baseline), 1e-3)
        for name, fn in models.items():
            try:
                pred = np.asarray(fn(train, val_h, periods), dtype=float)
                if pred.shape != (val_h,) or not np.isfinite(pred).all():
                    continue
                mase = _mase(actual, pred, train, periods)
                smape = _smape(actual, pred)
                loss = 0.5 * (mase / base_mase) + 0.5 * (smape / base_smape)
                per_model_losses[name].append(float(np.clip(loss, 0.0, 20.0)))
                pooled_errors[name].append(actual - pred)
                successful.add(name)
            except Exception:
                continue

    if not successful:
        point = _naive(y, horizon, periods)
        width = np.full(horizon, 1.645 * max(float(np.std(np.diff(y))), 1e-6))
        return ForecastResult(point, point - width, point + width, {"fallback": True})

    losses = {
        name: float(np.median(per_model_losses[name]))
        for name in successful
        if len(per_model_losses[name]) >= max(1, len(origins) - 1)
    }
    if not losses:
        losses = {name: float(np.mean(per_model_losses[name])) for name in successful if per_model_losses[name]}
    ordered = sorted(losses, key=losses.get)
    selected = ordered[: min(4, len(ordered))]
    loss_values = np.asarray([losses[name] for name in selected], dtype=float)
    spread = max(float(np.median(loss_values) - np.min(loss_values)), 0.05)
    weights = softmax(-3.0 * (loss_values - np.min(loss_values)) / spread)
    weights = 0.85 * np.eye(len(selected))[0] + 0.15 * weights if len(selected) > 1 else np.ones(1)
    weights = weights / weights.sum()

    future_predictions = []
    final_names = []
    final_weights = []
    for name, weight in zip(selected, weights):
        try:
            pred = np.asarray(models[name](y, horizon, periods), dtype=float)
            if pred.shape == (horizon,) and np.isfinite(pred).all():
                future_predictions.append(pred)
                final_names.append(name)
                final_weights.append(float(weight))
        except Exception:
            continue
    if not future_predictions:
        future_predictions = [_naive(y, horizon, periods)]
        final_names = ["naive_fallback"]
        final_weights = [1.0]
    final_weights_arr = np.asarray(final_weights, dtype=float)
    final_weights_arr /= final_weights_arr.sum()
    point = np.average(np.vstack(future_predictions), axis=0, weights=final_weights_arr)

    residuals = []
    for name, weight in zip(final_names, final_weights_arr):
        if name in pooled_errors and pooled_errors[name]:
            errors = np.concatenate(pooled_errors[name])
            residuals.append(weight * errors)
    if residuals:
        pooled = np.sum(np.vstack([r[: min(map(len, residuals))] for r in residuals]), axis=0)
    else:
        pooled = np.diff(y)
    pooled = pooled[np.isfinite(pooled)]
    if pooled.size < 5:
        pooled = np.diff(y)
    alpha = max(0.01, 1.0 - interval_level)
    quantile = float(np.quantile(np.abs(pooled), min(0.995, 1.0 - alpha / 2.0)))
    quantile = max(quantile, 0.25 * max(float(np.std(pooled)), 1e-6))
    reference = min(periods, default=max(1, horizon))
    growth = np.sqrt(1.0 + np.arange(horizon, dtype=float) / max(reference, 1))
    width = 1.10 * quantile * growth
    lower = point - width
    upper = point + width
    if np.min(y) >= 0:
        lower = np.maximum(lower, 0.0)

    diagnostics: dict[str, Any] = {
        "history_length": int(len(y)),
        "horizon": int(horizon),
        "seasonal_periods": list(periods),
        "validation_origins": origins,
        "validation_horizon": int(val_h),
        "model_count": int(len(models)),
        "selected_models": final_names,
        "selected_weights": [float(x) for x in final_weights_arr],
        "validation_losses": {name: losses[name] for name in ordered},
        "interval_level": float(interval_level),
        "interval_residual_quantile": quantile,
        "finite": bool(np.isfinite(point).all() and np.isfinite(lower).all() and np.isfinite(upper).all()),
    }
    return ForecastResult(point=point, lower=lower, upper=upper, diagnostics=diagnostics)
