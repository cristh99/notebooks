from __future__ import annotations

import argparse
import json
import math
import time
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from statsmodels.tsa.holtwinters import Holt

from forecaster import forecast_series


def _load_series(item: dict[str, Any]) -> np.ndarray:
    frame = pd.read_csv(item["path"])
    time_column = item.get("time_column")
    if time_column:
        parsed = pd.to_datetime(frame[time_column], errors="coerce")
        frame = frame.assign(_parsed_time=parsed).sort_values("_parsed_time")
    values = pd.to_numeric(frame[item["value_column"]], errors="coerce").to_numpy(dtype=float)
    values = values[np.isfinite(values)]
    max_history = int(item.get("max_history", 0) or 0)
    if max_history > 0 and values.size > max_history:
        values = values[-max_history:]
    horizon = int(item["horizon"])
    if values.size < horizon + 24:
        raise ValueError(f"series {item['role']} is too short")
    return values


def _periods(item: dict[str, Any], n: int) -> tuple[int, ...]:
    return tuple(sorted({int(p) for p in item.get("seasonal_periods", []) if 2 <= int(p) < n // 2}))


def _repeat_cycle(cycle: np.ndarray, horizon: int) -> np.ndarray:
    return np.resize(np.asarray(cycle, dtype=float), horizon)


def _naive(train: np.ndarray, horizon: int) -> np.ndarray:
    return np.full(horizon, train[-1], dtype=float)


def _drift(train: np.ndarray, horizon: int) -> np.ndarray:
    window = min(len(train), max(20, len(train) // 2))
    slope = (train[-1] - train[-window]) / max(window - 1, 1)
    return train[-1] + slope * np.arange(1, horizon + 1)


def _holt(train: np.ndarray, horizon: int) -> np.ndarray:
    fit = Holt(train, damped_trend=True, initialization_method="estimated").fit(optimized=True)
    return np.asarray(fit.forecast(horizon), dtype=float)


def _seasonal_naive(train: np.ndarray, horizon: int, period: int) -> np.ndarray:
    return _repeat_cycle(train[-period:], horizon)


def _scale(train: np.ndarray, periods: tuple[int, ...]) -> float:
    p = periods[0] if periods and len(train) > periods[0] else 1
    diffs = np.abs(train[p:] - train[:-p])
    scale = float(np.mean(diffs)) if diffs.size else float(np.mean(np.abs(np.diff(train))))
    if not np.isfinite(scale) or scale < 1e-8:
        scale = max(float(np.std(train)), 1.0)
    return scale


def _smape(actual: np.ndarray, pred: np.ndarray) -> float:
    return float(200.0 * np.mean(np.abs(actual - pred) / np.maximum(np.abs(actual) + np.abs(pred), 1e-8)))


def _metrics(actual: np.ndarray, pred: np.ndarray, train: np.ndarray, periods: tuple[int, ...]) -> dict[str, float]:
    scale = _scale(train, periods)
    errors = actual - pred
    return {
        "mae": float(np.mean(np.abs(errors))),
        "rmse": float(np.sqrt(np.mean(errors ** 2))),
        "mase": float(np.mean(np.abs(errors)) / scale),
        "smape": _smape(actual, pred),
        "scale": scale,
    }


def _interval_metrics(actual: np.ndarray, lower: np.ndarray, upper: np.ndarray, scale: float, level: float) -> dict[str, float]:
    alpha = 1.0 - level
    below = actual < lower
    above = actual > upper
    width = upper - lower
    winkler = width + (2.0 / alpha) * (lower - actual) * below + (2.0 / alpha) * (actual - upper) * above
    return {
        "coverage": float(np.mean((actual >= lower) & (actual <= upper))),
        "normalized_width": float(np.mean(width) / max(scale, 1e-8)),
        "normalized_winkler": float(np.mean(winkler) / max(scale, 1e-8)),
    }


def run(manifest: dict[str, Any]) -> dict[str, Any]:
    rows: list[dict[str, Any]] = []
    started = time.perf_counter()
    for item in manifest["datasets"]:
        values = _load_series(item)
        horizon = int(item["horizon"])
        train = values[:-horizon]
        actual = values[-horizon:]
        periods = _periods(item, len(train))
        item_started = time.perf_counter()

        candidate = forecast_series(
            train,
            horizon,
            periods,
            interval_level=float(manifest.get("interval_level", 0.90)),
        )
        candidate_metrics = _metrics(actual, candidate.point, train, periods)
        candidate_metrics.update(
            _interval_metrics(
                actual,
                candidate.lower,
                candidate.upper,
                candidate_metrics["scale"],
                float(manifest.get("interval_level", 0.90)),
            )
        )

        baseline_predictions: dict[str, np.ndarray] = {
            "naive": _naive(train, horizon),
            "drift": _drift(train, horizon),
        }
        try:
            baseline_predictions["holt_damped"] = _holt(train, horizon)
        except Exception:
            pass
        for period in periods:
            baseline_predictions[f"seasonal_naive_{period}"] = _seasonal_naive(train, horizon, period)

        baselines = {
            name: _metrics(actual, pred, train, periods)
            for name, pred in baseline_predictions.items()
            if pred.shape == actual.shape and np.isfinite(pred).all()
        }
        reference_name = f"seasonal_naive_{periods[0]}" if periods and f"seasonal_naive_{periods[0]}" in baselines else "naive"
        reference = baselines[reference_name]
        reference_mase = max(reference["mase"], 1e-6)
        reference_smape = max(reference["smape"], 1e-6)

        def owa(metrics: dict[str, float]) -> float:
            return float(0.5 * metrics["mase"] / reference_mase + 0.5 * metrics["smape"] / reference_smape)

        candidate_owa = owa(candidate_metrics)
        baseline_owa = {name: owa(metrics) for name, metrics in baselines.items()}
        best_name = min(baseline_owa, key=baseline_owa.get)
        best_loss = baseline_owa[best_name]
        advantage = best_loss - candidate_owa

        rows.append(
            {
                "role": item["role"],
                "history_length": int(len(train)),
                "horizon": horizon,
                "seasonal_periods": list(periods),
                "candidate": {**candidate_metrics, "owa": candidate_owa},
                "baselines": {
                    name: {**baselines[name], "owa": baseline_owa[name]}
                    for name in baselines
                },
                "reference_baseline": reference_name,
                "best_baseline": best_name,
                "advantage_vs_best": float(advantage),
                "candidate_wins": bool(advantage > 0.0),
                "diagnostics": candidate.diagnostics,
                "elapsed_seconds": float(time.perf_counter() - item_started),
            }
        )

    summary = {
        "dataset_count": len(rows),
        "finite_all": bool(
            all(
                math.isfinite(row["candidate"]["owa"])
                and bool(row["diagnostics"].get("finite", False))
                for row in rows
            )
        ),
        "candidate_mean_mase": float(np.mean([row["candidate"]["mase"] for row in rows])),
        "candidate_median_mase": float(np.median([row["candidate"]["mase"] for row in rows])),
        "candidate_mean_smape": float(np.mean([row["candidate"]["smape"] for row in rows])),
        "candidate_mean_owa": float(np.mean([row["candidate"]["owa"] for row in rows])),
        "candidate_mean_coverage": float(np.mean([row["candidate"]["coverage"] for row in rows])),
        "candidate_mean_normalized_width": float(np.mean([row["candidate"]["normalized_width"] for row in rows])),
        "candidate_mean_normalized_winkler": float(np.mean([row["candidate"]["normalized_winkler"] for row in rows])),
        "mean_advantage_vs_best": float(np.mean([row["advantage_vs_best"] for row in rows])),
        "worst_advantage_vs_best": float(np.min([row["advantage_vs_best"] for row in rows])),
        "wins_vs_best": int(sum(row["candidate_wins"] for row in rows)),
        "total_elapsed_seconds": float(time.perf_counter() - started),
    }
    return {
        "schema": "data-science-god-level/time-series-transfer-report/1",
        "manifest": manifest,
        "datasets": rows,
        "summary": summary,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    manifest = json.loads(Path(args.manifest).read_text(encoding="utf-8"))
    report = run(manifest)
    payload = json.dumps(report, indent=2, sort_keys=True) + "\n"
    Path(args.output).write_text(payload, encoding="utf-8")
    print(payload)


if __name__ == "__main__":
    main()
