from __future__ import annotations

import json
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REFERENCE = json.loads((ROOT / "reference_ANALYSIS_CONTRACT.json").read_text())
ADAPTER = json.loads((ROOT / "ANALYSIS_REAL_CANARY_CONTRACT.json").read_text())


class AnalyzeReferenceContractTests(unittest.TestCase):
    def test_01_schema(self):
        self.assertEqual(REFERENCE["schema"], "data-science-pipeline/analyze-contract/3")

    def test_02_stage(self):
        self.assertEqual(REFERENCE["stage"], "09 — Analyze")

    def test_03_status(self):
        self.assertEqual(REFERENCE["status"], "IMPLEMENTED / REAL_DATA_RUN_OPEN")

    def test_04_coordination(self):
        self.assertEqual(REFERENCE["coordination_id"], "COORD-2026-08-06-PARALLEL-V2")

    def test_05_analysis_mode(self):
        self.assertEqual(REFERENCE["analysis_mode"], "preregistered_descriptive_inferential_no_model_fit")

    def test_06_population_event_role(self):
        self.assertEqual(REFERENCE["analysis_population"]["event_role"], "CONTRACT")

    def test_07_population_amount_role(self):
        self.assertEqual(REFERENCE["analysis_population"]["amount_role"], "CONTRACT_VALUE")

    def test_08_population_date_role(self):
        self.assertEqual(REFERENCE["analysis_population"]["date_role"], "CONTRACT_DATE")

    def test_09_cross_role_exclusion(self):
        self.assertEqual(REFERENCE["analysis_population"]["excluded_role_policy"], "report_explicitly_never_aggregate_across_roles")

    def test_10_historical_snapshot_schema(self):
        self.assertEqual(REFERENCE["input_contract"]["required_snapshot_schema"], "data-science-pipeline/semantic-snapshot/2")

    def test_11_terminal_input_state(self):
        self.assertEqual(REFERENCE["input_contract"]["required_terminal_state"], "SEMANTIC_VALIDATED")

    def test_12_currency(self):
        self.assertEqual(REFERENCE["input_contract"]["required_currency"], "HNL")

    def test_13_grain(self):
        self.assertEqual(REFERENCE["input_contract"]["required_grain"], "one resolved procurement event with explicit event, amount and date roles")

    def test_14_lineage_required(self):
        self.assertIs(REFERENCE["input_contract"]["lineage_required"], True)

    def test_15_missingness_policy(self):
        self.assertEqual(REFERENCE["input_contract"]["missingness_policy"], "explicit_never_silent_imputation")

    def test_16_quarantine_empty(self):
        self.assertIs(REFERENCE["input_contract"]["quarantine_must_be_empty"], True)

    def test_17_one_hypothesis(self):
        self.assertEqual(len(REFERENCE["hypotheses"]), 1)

    def test_18_hypothesis_id(self):
        self.assertEqual(REFERENCE["hypotheses"][0]["id"], "H09-001")

    def test_19_hypothesis_groups(self):
        self.assertEqual(REFERENCE["hypotheses"][0]["groups"], ["DIRECT", "OPEN"])

    def test_20_hypothesis_outcome(self):
        self.assertEqual(REFERENCE["hypotheses"][0]["outcome"], "low_competition")

    def test_21_hypothesis_test(self):
        self.assertEqual(REFERENCE["hypotheses"][0]["test"], "two_sided_fisher_exact")

    def test_22_hypothesis_effect(self):
        self.assertEqual(REFERENCE["hypotheses"][0]["effect"], "risk_difference_direct_minus_open")

    def test_23_hypothesis_noncausal(self):
        self.assertIs(REFERENCE["hypotheses"][0]["causal"], False)

    def test_24_causal_claims_forbidden(self):
        self.assertIs(REFERENCE["claim_policy"]["causal_claims_forbidden"], True)

    def test_25_association_not_causation(self):
        self.assertIs(REFERENCE["claim_policy"]["association_must_not_be_described_as_causation"], True)

    def test_26_wrongdoing_forbidden(self):
        self.assertIs(REFERENCE["claim_policy"]["wrongdoing_labels_forbidden"], True)

    def test_27_public_rankings_forbidden(self):
        self.assertIs(REFERENCE["claim_policy"]["public_rankings_forbidden"], True)

    def test_28_review_required(self):
        self.assertIs(REFERENCE["claim_policy"]["human_or_governed_review_required_before_publication"], True)

    def test_29_baseline_id(self):
        self.assertEqual(REFERENCE["baseline"]["id"], "B09-POOLED-RATE")

    def test_30_baseline_role(self):
        self.assertEqual(REFERENCE["baseline"]["role"], "descriptive null baseline")

    def test_31_confidence_level(self):
        self.assertEqual(REFERENCE["statistics"]["confidence_level"], 0.95)

    def test_32_minimum_cell(self):
        self.assertEqual(REFERENCE["statistics"]["minimum_cell_n"], 5)

    def test_33_fdr_method(self):
        self.assertEqual(REFERENCE["statistics"]["fdr_method"], "Benjamini-Hochberg")

    def test_34_fdr_q(self):
        self.assertEqual(REFERENCE["statistics"]["fdr_q"], 0.05)

    def test_35_no_model_selection(self):
        self.assertIs(REFERENCE["statistics"]["model_selection_performed"], False)

    def test_36_effect_required_when_evaluable(self):
        self.assertIs(REFERENCE["statistics"]["effect_size_required"], True)

    def test_37_uncertainty_required_when_evaluable(self):
        self.assertIs(REFERENCE["statistics"]["uncertainty_required"], True)

    def test_38_negative_control_cannot_promote(self):
        self.assertEqual(REFERENCE["negative_controls"][0]["id"], "NC09-001")
        self.assertIs(REFERENCE["negative_controls"][0]["must_not_promote"], True)

    def test_39_terminal_states(self):
        self.assertEqual(
            REFERENCE["terminal_states"],
            ["ANALYSIS_EXECUTION_VALIDATED", "ANALYSIS_NOT_EVALUABLE", "ANALYSIS_QUARANTINED"],
        )

    def test_40_explicit_v3_adapter_preserves_noncompensable_gates(self):
        self.assertEqual(ADAPTER["input_contract"]["required_snapshot_schema"], "data-science-pipeline/semantic-snapshot/3")
        self.assertEqual(ADAPTER["analyze_reference"]["analysis_contract_sha256"], "d0e94b6d1c558132cfc1d35e988b6219cd4eda28865320801b75ab780ea7600c")
        self.assertEqual(ADAPTER["statistics"]["minimum_cell_n"], REFERENCE["statistics"]["minimum_cell_n"])
        self.assertEqual(ADAPTER["hypothesis"]["id"], REFERENCE["hypotheses"][0]["id"])
        self.assertEqual(ADAPTER["hypothesis"]["groups"], REFERENCE["hypotheses"][0]["groups"])
        self.assertEqual(ADAPTER["hypothesis"]["test"], REFERENCE["hypotheses"][0]["test"])
        self.assertEqual(ADAPTER["hypothesis"]["effect"], REFERENCE["hypotheses"][0]["effect"])
        self.assertIs(ADAPTER["statistics"]["model_selection_performed"], False)
        self.assertIs(ADAPTER["claim_policy"]["no p_value_when_not_evaluable"], True)
        self.assertIs(ADAPTER["claim_policy"]["no effect_when_not_evaluable"], True)


if __name__ == "__main__":
    unittest.main(verbosity=2)
