from __future__ import annotations

import base64
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import urllib.request
from pathlib import Path, PurePosixPath
from zipfile import BadZipFile, ZipFile

REPOSITORY = "cristh99/notebooks"
BRANCH = "agent/data-science-v14-2-analyze-real-not-evaluable-v1"
WORKFLOW_PATH = ".github/workflows/data-science-v14-2-analyze-real.yml"
OIDC_ISSUER = "https://token.actions.githubusercontent.com"
OIDC_AUDIENCE = "sigstore"
COSIGN_VERSION = "3.0.6"
COSIGN_SHA256 = "c956e5dfcac53d52bcf058360d579472f0c1d2d9b69f55209e256fe7783f4c74"

SEMANTIC = {
    "component": "data_science_pipeline_v13_2_semantic_real",
    "package": "semantic-source.zip",
    "package_sha256": "114b40590a9e4c4c32e8843fc1be347a8e877f0f9a18044c82a8c16c78295575",
    "package_blob": "346caa6901d504fcb7da5b5cdc47812a33049ad2",
    "package_manifest_sha256": "fa19c95c820f045e2395f117cf79e0121c6e94a4ae0ec1c2880cd0c54e8aefa5",
    "transport_manifest_sha256": "3aa6e8a3cca405403b424a921c22d97d257dad317263b393495fd0b1124fb06a",
    "snapshot_sha256": "f2032c782da735cafe4bb29d76f49f04fbd580a8d810f59a77d588908271371b",
    "input_sha256": "d3a4403c718c5d92a86d21407351ec0459cc772d8a5a2dd0498291af7926449e",
    "commit": "1de729a9466dfe714326b1a80087e74e32bea780",
    "artifact_id": 8982588063,
    "artifact_digest": "sha256:96c151dd16bcdc64cc21ad88cd26f1d10cc44555d3e809f75a6be006a00b8a77",
    "external_receipt_sha256": "da044a14388dfe49933410e3f9d4ecbae3b70c1a865bd31fb1c7678858315cf4",
    "bundle_sha256": "7a2cdf0c592448afea2a1cfa6392e73bae7971446987e64883b219a75f62b102",
    "safe_claims_sha256": "8e2954af9fb3c328d51892e418f2a3509d6b04dfcd8027877a5e6f0cf55fbe74",
    "verify_log_sha256": "80a53f76c7ed6969dade3b6ee47cdb753162db7c00be625448999d08bae77ed8",
    "cert_id": "https://github.com/cristh99/notebooks/.github/workflows/data-science-v13-2-semantic-real.yml@refs/heads/agent/data-science-v13-2-semantic-real-source-native-v1",
}

ANALYZE = {
    "branch": "agent/data-science-v14-analyze-role-safe-v2",
    "commit": "d180310fe23a63b018f06de65b68fd879bea80d6",
    "capsule_path": "data_science_pipeline_v14_analyze_contract/capsule.zip",
    "historical_declared_capsule_sha256": "693d2035318e86a9f5c11c311d7e05bba09f35d46638cf47dcb18d424502eddb",
    "capsule_observed_sha256": "d14ff92591a0c864a75ade4fdc2e1ddf4224410fa5f3bcfff5bdec8b29b9542f",
    "capsule_bytes": 13116,
    "capsule_git_blob_sha1": "5602f1c12ff3b93d8e1a5995753b1e6bd94f2bd7",
    "contract_path": "data_science_pipeline_v14_analyze_contract/ANALYSIS_CONTRACT.json",
    "contract_git_blob_sha1": "81e523b81172e4ef1ac940436a946ca84e28de0b",
    "contract_sha256": "d0e94b6d1c558132cfc1d35e988b6219cd4eda28865320801b75ab780ea7600c",
    "implementation_sha256": "3dd839fb6e84738c435e087ff2ed122c4d2150d9ce703a3eb424318ec320b628",
    "tests_sha256": "3b2433317f47d4e2d2703c2d101ca3ec360f6b41221fe386c5ce45bec3fa4bdc",
    "verifier_sha256": "b9c7737bbf12b413c26eefe0c587e9b0b9febf4d7f7848c7eff27c895725fe17",
    "synthetic_result_sha256": "9bf30f57f02696aef3adc0de7858fe5139c587002604ffca64ed23a6a59a6651",
    "local_receipt_sha256": "f70d45ed9341a7c82a190a0cf7ece6c347d0529136d3571088fccbb06cad241c",
    "readme_sha256": "923c556ba7aa361e65b274a79d2b05aa0c224f97b33136c6ebd9fe7606c33e11",
}

LOCAL = {
    "protocol_sha256": "a5495c843aeb370c77d40836b9a29cd6beb58b8bc1f3086c56bbe155d3ff8159",
    "implementation_sha256": "d94914f765da7ef270c39b09b0feb2772bb10b6a750ef484887271b84bf8915c",
    "tests_sha256": "51db8d3abd2d736f44419740446462f2260485aa99370bd1d85eec4845f2f81a",
    "expected_result_sha256": "31330fd015a08eae104d7f2e69ebf0305eb75bbfc2a23bf9a5c9d5ba7e369b65",
    "readme_sha256": "512255d72dc40aca63c6bfa8f5461ae1a70d69546c8674343289167d3d04415f",
    "reference_tests_sha256": "863711b78a23f055cf34b505a419f4be1ca4966bfd07280f7ea1f12780c7419a",
}


def fail(message: str) -> None:
    raise SystemExit(message)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha_path(path: Path) -> str:
    return sha(path.read_bytes())


def git_blob(data: bytes) -> str:
    return hashlib.sha1(f"blob {len(data)}\0".encode() + data).hexdigest()


def canonical(value: object) -> bytes:
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n").encode()


def check_file(path: Path, digest: str) -> None:
    if sha_path(path) != digest:
        fail(f"SHA-256 mismatch: {path}")


def run(command: list[str], *, cwd: Path | None = None, log: Path | None = None) -> None:
    if log is None:
        subprocess.run(command, cwd=cwd, check=True)
        return
    with log.open("wb") as handle:
        proc = subprocess.run(command, cwd=cwd, stdout=handle, stderr=subprocess.STDOUT)
    if proc.returncode:
        fail(f"command failed ({proc.returncode}): {' '.join(command)}")


def check_log(path: Path, count: int) -> None:
    text = path.read_text(errors="replace")
    if re.search(rf"Ran {count} tests", text) is None or "\nOK\n" not in text:
        fail(f"test count/status mismatch: {path}")


def safe_extract(archive: Path, out: Path, expected: set[str]) -> None:
    with ZipFile(archive) as zf:
        names = zf.namelist()
        if len(names) != len(set(names)) or set(names) != expected:
            fail(f"unexpected ZIP members: {sorted(set(names) ^ expected)}")
        for name in names:
            member = PurePosixPath(name)
            if member.is_absolute() or ".." in member.parts:
                fail(f"unsafe ZIP member: {name}")
        zf.extractall(out)


def reconstruct_semantic(root: Path, evidence: Path) -> Path:
    component = root / SEMANTIC["component"]
    package_manifest_path = component / "SOURCE_PACKAGE_MANIFEST.json"
    transport_manifest_path = component / "PACKAGE_TRANSPORT_MANIFEST.json"
    check_file(package_manifest_path, SEMANTIC["package_manifest_sha256"])
    check_file(transport_manifest_path, SEMANTIC["transport_manifest_sha256"])
    package_manifest = json.loads(package_manifest_path.read_text())
    transport = json.loads(transport_manifest_path.read_text())
    actual = sorted(path.name for path in (component / "transport").glob("part_*.b64"))
    if actual != transport["part_order"]:
        fail("Semantic transport part set mismatch")
    chunks: list[bytes] = []
    for name in transport["part_order"]:
        data = (component / "transport" / name).read_bytes()
        expected = transport["parts"][name]
        if len(data) != expected["bytes"] or sha(data) != expected["sha256"] or git_blob(data) != expected["git_blob_sha1"]:
            fail(f"Semantic transport mismatch: {name}")
        chunks.append(data)
    encoded = b"".join(chunks)
    decoded = base64.b64decode(encoded, validate=True)
    if len(encoded) != transport["base64_characters"] or len(decoded) != transport["decoded_bytes"]:
        fail("Semantic package size mismatch")
    if sha(decoded) != SEMANTIC["package_sha256"] or git_blob(decoded) != SEMANTIC["package_blob"]:
        fail("Semantic package commitment mismatch")
    archive = root / SEMANTIC["package"]
    archive.write_bytes(decoded)
    with ZipFile(archive) as zf:
        names = zf.namelist()
        if len(names) != len(set(names)) or set(names) != set(package_manifest["members"]):
            fail("Semantic package member set mismatch")
        for name in names:
            member = PurePosixPath(name)
            if member.is_absolute() or ".." in member.parts or len(member.parts) != 1:
                fail(f"unsafe Semantic package member: {name}")
            data = zf.read(name)
            expected = package_manifest["members"][name]
            if len(data) != expected["bytes"] or sha(data) != expected["sha256"]:
                fail(f"Semantic package member mismatch: {name}")
        zf.extractall(component)
    check_file(component / "REAL_SEMANTIC_SNAPSHOT.json", SEMANTIC["snapshot_sha256"])
    check_file(component / "SOURCE_NATIVE_EVENTS.jsonl", SEMANTIC["input_sha256"])
    run([sys.executable, "-m", "unittest", "-v", "test_semantic_real.py"], cwd=component, log=evidence / "semantic-tests.log")
    check_log(evidence / "semantic-tests.log", 60)
    run([sys.executable, "verify.py", "--output", str(evidence / "semantic-local-receipt.json")], cwd=component, log=evidence / "semantic-local-verification.log")
    if (component / "LOCAL_RESULT.json").read_bytes() != (evidence / "semantic-local-receipt.json").read_bytes():
        fail("Semantic local receipt replay mismatch")
    run([sys.executable, "semantic_real.py", "--contract", "SEMANTIC_REAL_CONTRACT.json", "--input", "SOURCE_NATIVE_EVENTS.jsonl", "--output", str(evidence / "semantic-replay.json")], cwd=component)
    if (component / "REAL_SEMANTIC_SNAPSHOT.json").read_bytes() != (evidence / "semantic-replay.json").read_bytes():
        fail("Semantic snapshot replay mismatch")
    return component


def fetch_analyze_reference(root: Path, temp: Path, evidence: Path) -> Path:
    run(["git", "fetch", "--no-tags", "--depth=1", f"https://github.com/{REPOSITORY}.git", f"refs/heads/{ANALYZE['branch']}"])
    head = subprocess.check_output(["git", "rev-parse", "FETCH_HEAD"], text=True).strip()
    if head != ANALYZE["commit"]:
        fail("Analyze reference commit mismatch")

    capsule = temp / "analyze-reference-corrupt-capsule.bin"
    with capsule.open("wb") as handle:
        proc = subprocess.run(["git", "show", f"{ANALYZE['commit']}:{ANALYZE['capsule_path']}"], stdout=handle)
    if proc.returncode:
        fail("Unable to read historical Analyze capsule")
    capsule_bytes = capsule.read_bytes()
    if len(capsule_bytes) != ANALYZE["capsule_bytes"]:
        fail("Historical Analyze capsule size mismatch")
    if git_blob(capsule_bytes) != ANALYZE["capsule_git_blob_sha1"]:
        fail("Historical Analyze capsule Git blob mismatch")
    if sha(capsule_bytes) != ANALYZE["capsule_observed_sha256"]:
        fail("Historical Analyze capsule observed SHA-256 mismatch")
    zip_valid = True
    zip_error = None
    try:
        with ZipFile(capsule) as zf:
            zf.namelist()
    except BadZipFile as exc:
        zip_valid = False
        zip_error = str(exc)
    if zip_valid:
        fail("Historical Analyze capsule unexpectedly became a valid ZIP")
    if ANALYZE["capsule_observed_sha256"] == ANALYZE["historical_declared_capsule_sha256"]:
        fail("Historical Analyze capsule defect expectation drifted")

    reference_contract = temp / "reference_ANALYSIS_CONTRACT.json"
    with reference_contract.open("wb") as handle:
        proc = subprocess.run(["git", "show", f"{ANALYZE['commit']}:{ANALYZE['contract_path']}"], stdout=handle)
    if proc.returncode:
        fail("Unable to read Analyze reference contract")
    contract_bytes = reference_contract.read_bytes()
    if git_blob(contract_bytes) != ANALYZE["contract_git_blob_sha1"]:
        fail("Analyze reference contract Git blob mismatch")
    if sha(contract_bytes) != ANALYZE["contract_sha256"]:
        fail("Analyze reference contract SHA-256 mismatch")
    contract = json.loads(contract_bytes)
    if canonical(contract) != contract_bytes:
        fail("Analyze reference contract is not canonical JSON")

    component = root / "data_science_pipeline_v14_2_analyze_real"
    shutil.copyfile(reference_contract, component / "reference_ANALYSIS_CONTRACT.json")
    observation = {
        "schema": "data-science-pipeline/analyze-reference-integrity-observation/1",
        "pr": 143,
        "commit": ANALYZE["commit"],
        "capsule_path": ANALYZE["capsule_path"],
        "capsule_git_blob_sha1": ANALYZE["capsule_git_blob_sha1"],
        "capsule_bytes": len(capsule_bytes),
        "capsule_observed_sha256": sha(capsule_bytes),
        "capsule_historical_declared_sha256": ANALYZE["historical_declared_capsule_sha256"],
        "capsule_declared_sha_matches_observed": sha(capsule_bytes) == ANALYZE["historical_declared_capsule_sha256"],
        "capsule_valid_zip": zip_valid,
        "capsule_error": zip_error,
        "integrity_status": "PR143_PACKAGE_INTEGRITY_DEFECT",
        "contract_path": ANALYZE["contract_path"],
        "contract_git_blob_sha1": ANALYZE["contract_git_blob_sha1"],
        "contract_sha256": sha(contract_bytes),
        "contract_canonical_json": True,
        "execution_mode": "INDEPENDENT_CONTRACT_CONFORMANCE_TESTS",
        "historical_40_tests_claimed": False,
        "independent_contract_tests_expected": 40,
        "claim_boundary": "The corrupt historical capsule is preserved as a defect and is never executed. Only the exact canonical contract is reused, under a new independent 40-test conformance suite.",
    }
    (evidence / "analyze-reference-integrity-observation.json").write_bytes(canonical(observation))
    shutil.copyfile(reference_contract, evidence / "reference_ANALYSIS_CONTRACT.json")
    run([sys.executable, "-m", "unittest", "-v", "test_reference_contract.py"], cwd=component, log=evidence / "analyze-reference-tests.log")
    check_log(evidence / "analyze-reference-tests.log", 40)
    return reference_contract


def execute_canary(component: Path, semantic_component: Path, reference_contract: Path, evidence: Path) -> None:
    shutil.copyfile(semantic_component / "REAL_SEMANTIC_SNAPSHOT.json", component / "REAL_SEMANTIC_SNAPSHOT.json")
    shutil.copyfile(reference_contract, component / "reference_ANALYSIS_CONTRACT.json")
    check_file(component / "REAL_SEMANTIC_SNAPSHOT.json", SEMANTIC["snapshot_sha256"])
    check_file(component / "reference_ANALYSIS_CONTRACT.json", ANALYZE["contract_sha256"])
    run([sys.executable, "-m", "unittest", "-v", "test_real_canary.py"], cwd=component, log=evidence / "canary-tests.log")
    check_log(evidence / "canary-tests.log", 44)
    command = [sys.executable, "run_real_canary.py", "--snapshot", "REAL_SEMANTIC_SNAPSHOT.json", "--protocol", "ANALYSIS_REAL_CANARY_CONTRACT.json", "--reference-contract", "reference_ANALYSIS_CONTRACT.json"]
    run(command + ["--output", str(evidence / "REAL_ANALYSIS_RESULT.json")], cwd=component, log=evidence / "canary-run.log")
    run(command + ["--output", str(evidence / "replay.json")], cwd=component, log=evidence / "replay.log")
    expected = component / "EXPECTED_RESULT.json"
    if expected.read_bytes() != (evidence / "REAL_ANALYSIS_RESULT.json").read_bytes() or expected.read_bytes() != (evidence / "replay.json").read_bytes():
        fail("Analyze canary deterministic result mismatch")
    check_file(evidence / "REAL_ANALYSIS_RESULT.json", LOCAL["expected_result_sha256"])


def github_request(url: str, token: str, *, output: Path | None = None) -> bytes:
    request = urllib.request.Request(url, headers={"Authorization": f"Bearer {token}", "Accept": "application/vnd.github+json", "X-GitHub-Api-Version": "2022-11-28"})
    with urllib.request.urlopen(request) as response:
        data = response.read()
    if output is not None:
        output.write_bytes(data)
    return data


def find_unique(root: Path, name: str) -> Path:
    matches = list(root.rglob(name))
    if len(matches) != 1:
        fail(f"Expected one {name}, found {len(matches)}")
    return matches[0]


def download_and_verify_upstream(root: Path, component: Path, evidence: Path, cosign: Path) -> dict[str, object]:
    token = os.environ["GH_TOKEN"]
    api = f"https://api.github.com/repos/{REPOSITORY}/actions/artifacts/{SEMANTIC['artifact_id']}"
    meta_bytes = github_request(api, token)
    meta = json.loads(meta_bytes)
    if meta.get("digest") != SEMANTIC["artifact_digest"]:
        fail("Semantic artifact digest mismatch")
    (evidence / "semantic-artifact-metadata.json").write_bytes(canonical(meta))
    archive = evidence / "semantic-artifact.zip"
    github_request(api + "/zip", token, output=archive)
    if f"sha256:{sha_path(archive)}" != SEMANTIC["artifact_digest"]:
        fail("Downloaded Semantic artifact ZIP mismatch")
    artifact_root = root / "semantic-artifact"
    artifact_root.mkdir(parents=True, exist_ok=True)
    with ZipFile(archive) as zf:
        for name in zf.namelist():
            member = PurePosixPath(name)
            if member.is_absolute() or ".." in member.parts:
                fail(f"unsafe Semantic artifact member: {name}")
        zf.extractall(artifact_root)
    mapping = {
        "semantic-real.sigstore.json": ("upstream-semantic.sigstore.json", SEMANTIC["bundle_sha256"]),
        "external-receipt.json": ("upstream-semantic-external-receipt.json", SEMANTIC["external_receipt_sha256"]),
        "oidc-safe-claims.json": ("upstream-semantic-oidc-safe-claims.json", SEMANTIC["safe_claims_sha256"]),
        "verify.log": ("upstream-semantic-verify.log", SEMANTIC["verify_log_sha256"]),
        "replay-snapshot.json": ("upstream-semantic-snapshot.json", SEMANTIC["snapshot_sha256"]),
    }
    for source_name, (dest_name, digest) in mapping.items():
        dest = evidence / dest_name
        shutil.copyfile(find_unique(artifact_root, source_name), dest)
        check_file(dest, digest)
    if (component / "REAL_SEMANTIC_SNAPSHOT.json").read_bytes() != (evidence / "upstream-semantic-snapshot.json").read_bytes():
        fail("Upstream signed snapshot mismatch")
    run([str(cosign), "verify-blob", str(component / "REAL_SEMANTIC_SNAPSHOT.json"), "--bundle", str(evidence / "upstream-semantic.sigstore.json"), "--certificate-identity", SEMANTIC["cert_id"], "--certificate-oidc-issuer", OIDC_ISSUER, "--certificate-github-workflow-repository", REPOSITORY, "--certificate-github-workflow-sha", SEMANTIC["commit"], "--certificate-github-workflow-trigger", "push"], log=evidence / "upstream-semantic-reverify.log")
    if "Verified OK" not in (evidence / "upstream-semantic-reverify.log").read_text():
        fail("Upstream Semantic signature verification failed")
    return json.loads((evidence / "upstream-semantic-external-receipt.json").read_text())


def install_cosign(temp: Path, evidence: Path) -> Path:
    cosign = temp / "cosign"
    url = f"https://github.com/sigstore/cosign/releases/download/v{COSIGN_VERSION}/cosign-linux-amd64"
    with urllib.request.urlopen(url) as response:
        cosign.write_bytes(response.read())
    check_file(cosign, COSIGN_SHA256)
    cosign.chmod(0o755)
    run([str(cosign), "version"], log=evidence / "cosign-version.txt")
    return cosign


def get_oidc_token(evidence: Path) -> str:
    request_url = os.environ["ACTIONS_ID_TOKEN_REQUEST_URL"] + f"&audience={OIDC_AUDIENCE}"
    request = urllib.request.Request(request_url, headers={"Authorization": f"bearer {os.environ['ACTIONS_ID_TOKEN_REQUEST_TOKEN']}"})
    with urllib.request.urlopen(request) as response:
        token = json.loads(response.read())["value"]
    print(f"::add-mask::{token}")
    payload = token.split(".")[1]
    payload += "=" * ((4 - len(payload) % 4) % 4)
    claims = json.loads(base64.urlsafe_b64decode(payload))
    expected_ref = f"refs/heads/{BRANCH}"
    expected_sub = f"repo:{REPOSITORY}:ref:{expected_ref}"
    expected_workflow_ref = f"{REPOSITORY}/{WORKFLOW_PATH}@{expected_ref}"
    checks = {
        "iss": claims.get("iss") == OIDC_ISSUER,
        "aud": claims.get("aud") == OIDC_AUDIENCE,
        "sub": claims.get("sub") == expected_sub,
        "repository": claims.get("repository") == REPOSITORY,
        "ref": claims.get("ref") == expected_ref,
        "sha": claims.get("sha") == os.environ["GITHUB_SHA"],
        "workflow_ref": claims.get("workflow_ref") == expected_workflow_ref,
        "runner_github_hosted": claims.get("runner_environment") == "github-hosted",
        "event_push": claims.get("event_name") == "push",
    }
    if not all(checks.values()):
        fail(f"OIDC claim mismatch: {checks}")
    safe = {"claims": {key: claims.get(key) for key in ["iss", "aud", "sub", "repository", "ref", "sha", "workflow_ref", "event_name", "run_id", "run_attempt", "runner_environment"]}, "checks": checks, "jwt_sha256": sha(token.encode()), "token_redacted": True}
    (evidence / "oidc-safe-claims.json").write_bytes(canonical(safe))
    return token


def finalize(component: Path, evidence: Path, upstream: dict[str, object], cosign: Path) -> None:
    result_path = evidence / "REAL_ANALYSIS_RESULT.json"
    token = get_oidc_token(evidence)
    bundle_path = evidence / "analyze-real.sigstore.json"
    run([str(cosign), "sign-blob", "--yes", "--identity-token", token, "--bundle", str(bundle_path), str(result_path)], log=evidence / "sign.log")
    current_cert = f"https://github.com/{REPOSITORY}/{WORKFLOW_PATH}@refs/heads/{BRANCH}"
    run([str(cosign), "verify-blob", str(result_path), "--bundle", str(bundle_path), "--certificate-identity", current_cert, "--certificate-oidc-issuer", OIDC_ISSUER, "--certificate-github-workflow-repository", REPOSITORY, "--certificate-github-workflow-sha", os.environ["GITHUB_SHA"], "--certificate-github-workflow-trigger", os.environ["GITHUB_EVENT_NAME"]], log=evidence / "verify.log")
    result = json.loads(result_path.read_text())
    bundle = json.loads(bundle_path.read_text())
    entries = bundle.get("verificationMaterial", {}).get("tlogEntries", [])
    logs = {name: (evidence / file).read_text() for name, file in {"semantic": "semantic-tests.log", "reference": "analyze-reference-tests.log", "canary": "canary-tests.log"}.items()}
    reference_observation = json.loads((evidence / "analyze-reference-integrity-observation.json").read_text())
    checks = {
        "result_hash": sha_path(result_path) == LOCAL["expected_result_sha256"],
        "result_terminal": result["terminal_state"] == "ANALYSIS_NOT_EVALUABLE" and result["reason_code"] == "NOT_EVALUABLE_MIN_CELL_SIZE",
        "eligible_contract_count": result["population"]["eligible_records"] == 1,
        "group_counts": result["preregistered_hypothesis"]["group_counts"] == {"DIRECT": 0, "OPEN": 1},
        "minimum_cell_fixed": result["preregistered_hypothesis"]["minimum_cell_n"] == 5,
        "outcome_missing_preserved": result["missingness"]["eligible_low_competition_missing"] == 1 and result["missingness"]["silent_imputations"] == 0,
        "no_test": result["inference"]["test_executed"] is False,
        "no_p_value": result["inference"]["p_value"] is None,
        "no_effect": result["inference"]["effect_size"] is None and result["inference"]["confidence_interval"] is None,
        "no_fdr": result["inference"]["fdr_applied"] is False and result["inference"]["fdr_adjusted_p_value"] is None,
        "no_model": result["inference"]["model_fit_performed"] is False,
        "no_claims": all(value == 0 for value in result["claim_boundary"].values()),
        "stage10_blocked": result["readiness"]["stage10_canary_input_ready"] is False and result["readiness"]["stage10_global_unblocked"] is False,
        "zero_cost": result["governance"]["external_cost_usd"] == 0.0,
        "production_unmodified": result["governance"]["production_modified"] is False,
        "semantic_tests": re.search(r"Ran 60 tests", logs["semantic"]) is not None and "\nOK\n" in logs["semantic"],
        "reference_tests": re.search(r"Ran 40 tests", logs["reference"]) is not None and "\nOK\n" in logs["reference"],
        "reference_package_defect_confirmed": reference_observation["integrity_status"] == "PR143_PACKAGE_INTEGRITY_DEFECT" and reference_observation["capsule_valid_zip"] is False and reference_observation["capsule_declared_sha_matches_observed"] is False,
        "reference_contract_exact": reference_observation["contract_sha256"] == ANALYZE["contract_sha256"] and sha_path(component / "reference_ANALYSIS_CONTRACT.json") == ANALYZE["contract_sha256"],
        "reference_contract_canonical": reference_observation["contract_canonical_json"] is True,
        "historical_tests_not_claimed": reference_observation["historical_40_tests_claimed"] is False and reference_observation["independent_contract_tests_expected"] == 40,
        "reference_execution_mode_independent": reference_observation["execution_mode"] == "INDEPENDENT_CONTRACT_CONFORMANCE_TESTS",
        "canary_tests": re.search(r"Ran 44 tests", logs["canary"]) is not None and "\nOK\n" in logs["canary"],
        "upstream_external_terminal": upstream["verdict"] == "PASS_STAGE08_SEMANTIC_REAL_SOURCE_NATIVE_EXTERNAL",
        "upstream_snapshot_exact": sha_path(component / "REAL_SEMANTIC_SNAPSHOT.json") == SEMANTIC["snapshot_sha256"],
        "upstream_signature_reverified": "Verified OK" in (evidence / "upstream-semantic-reverify.log").read_text(),
        "current_signature_verified": "Verified OK" in (evidence / "verify.log").read_text(),
        "bundle_media_type": str(bundle.get("mediaType", "")).startswith("application/vnd.dev.sigstore.bundle.") and str(bundle.get("mediaType", "")).endswith("+json"),
        "transparency_log": isinstance(entries, list) and len(entries) >= 1,
        "replay_exact": result_path.read_bytes() == (evidence / "replay.json").read_bytes() == (component / "EXPECTED_RESULT.json").read_bytes(),
        "scientific_credit_zero": result["governance"]["scientific_promotion_credit"] == 0,
    }
    if not all(checks.values()):
        fail(f"terminal check failure: {checks}")
    receipt = {
        "schema": "data-science-pipeline/analyze-real-canary-external-receipt/1",
        "verdict": "PASS_STAGE09_REAL_CANARY_NOT_EVALUABLE_EXTERNAL",
        "github_run_id": int(os.environ["GITHUB_RUN_ID"]), "github_run_attempt": int(os.environ["GITHUB_RUN_ATTEMPT"]),
        "github_sha": os.environ["GITHUB_SHA"], "github_ref": os.environ["GITHUB_REF"], "repository": REPOSITORY,
        "semantic_pr": 149, "semantic_artifact_id": SEMANTIC["artifact_id"], "semantic_snapshot_sha256": SEMANTIC["snapshot_sha256"],
        "analyze_reference_pr": 143, "analyze_reference_commit": ANALYZE["commit"], "protocol_sha256": LOCAL["protocol_sha256"],
        "analyze_reference_capsule_git_blob_sha1": reference_observation["capsule_git_blob_sha1"],
        "analyze_reference_capsule_observed_sha256": reference_observation["capsule_observed_sha256"],
        "analyze_reference_capsule_bytes": reference_observation["capsule_bytes"],
        "analyze_reference_capsule_valid_zip": reference_observation["capsule_valid_zip"],
        "analyze_reference_capsule_historical_declared_sha256": reference_observation["capsule_historical_declared_sha256"],
        "analyze_reference_capsule_declared_sha_matches_observed": reference_observation["capsule_declared_sha_matches_observed"],
        "analyze_reference_contract_sha256": reference_observation["contract_sha256"],
        "analyze_reference_contract_git_blob_sha1": reference_observation["contract_git_blob_sha1"],
        "analyze_reference_execution_mode": reference_observation["execution_mode"],
        "analyze_reference_integrity_status": reference_observation["integrity_status"],
        "result_sha256": sha_path(result_path), "sigstore_bundle_sha256": sha_path(bundle_path), "verify_log_sha256": sha_path(evidence / "verify.log"),
        "oidc_safe_claims_sha256": sha_path(evidence / "oidc-safe-claims.json"), "checks": checks, "tests": "144/144 PASS", "test_breakdown": {"upstream_semantic": 60, "independent_reference_contract": 40, "bounded_real_canary": 44},
        "terminal_state": "ANALYSIS_NOT_EVALUABLE", "reason_code": "NOT_EVALUABLE_MIN_CELL_SIZE",
        "eligible_contract_records": 1, "excluded_payment_records": 1, "direct_records": 0, "open_records": 1,
        "observed_low_competition_records": 0, "test_executed": False, "p_value": None, "effect_size": None, "fdr_applied": False,
        "stage10_canary_input_ready": False, "stage10_global_unblocked": False, "external_real_data_evaluations": 1,
        "external_cost_usd": 0.0, "production_modified": False, "scientific_promotion_credit": 0,
        "next_gate": "preregistered scale-up with enough independently resolved CONTRACT records and observed low_competition; relationship remains excluded",
    }
    payload = canonical(receipt)
    (evidence / "external-receipt.json").write_bytes(payload)
    (evidence / "external-receipt.sha256").write_text(f"{sha(payload)}  external-receipt.json\n")
    files = sorted(path for path in evidence.iterdir() if path.is_file() and path.name != "MANIFEST.sha256")
    files += [component / name for name in ["README.md", "ANALYSIS_REAL_CANARY_CONTRACT.json", "EXPECTED_RESULT.json", "FREEZE.json", "source.zip", "ci.zip", "run_real_canary.py", "test_real_canary.py", "test_reference_contract.py", "ci_external.py", "reference_ANALYSIS_CONTRACT.json"]]
    (evidence / "MANIFEST.sha256").write_text("".join(f"{sha_path(path)}  {path}\n" for path in files))


def main() -> None:
    if os.environ.get("GITHUB_REPOSITORY") != REPOSITORY or os.environ.get("GITHUB_REF") != f"refs/heads/{BRANCH}":
        fail("repository/ref mismatch")
    if os.environ.get("GITHUB_EVENT_NAME") not in {"push", "workflow_dispatch"}:
        fail("event not allowed")
    root = Path.cwd()
    component = root / "data_science_pipeline_v14_2_analyze_real"
    evidence = root / "data-science-v14-2-analyze-real-evidence"
    temp = Path(os.environ["RUNNER_TEMP"])
    evidence.mkdir(parents=True, exist_ok=True)
    check_file(component / "ANALYSIS_REAL_CANARY_CONTRACT.json", LOCAL["protocol_sha256"])
    check_file(component / "run_real_canary.py", LOCAL["implementation_sha256"])
    check_file(component / "test_real_canary.py", LOCAL["tests_sha256"])
    check_file(component / "test_reference_contract.py", LOCAL["reference_tests_sha256"])
    check_file(component / "EXPECTED_RESULT.json", LOCAL["expected_result_sha256"])
    check_file(component / "README.md", LOCAL["readme_sha256"])
    semantic_component = reconstruct_semantic(root, evidence)
    reference_contract = fetch_analyze_reference(root, temp, evidence)
    execute_canary(component, semantic_component, reference_contract, evidence)
    cosign = install_cosign(temp, evidence)
    upstream = download_and_verify_upstream(temp, component, evidence, cosign)
    finalize(component, evidence, upstream, cosign)
    print("PASS_STAGE09_REAL_CANARY_NOT_EVALUABLE_EXTERNAL")


if __name__ == "__main__":
    main()
