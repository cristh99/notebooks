from __future__ import annotations

import argparse
import copy
import hashlib
import json
import re
from pathlib import Path
from typing import Any

HEX64 = re.compile(r"^[0-9a-f]{64}$")


class CanaryError(RuntimeError):
    pass


def canonical_bytes(value: Any) -> bytes:
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n").encode("utf-8")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_path(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


def require(condition: bool, message: str) -> None:
    if not condition:
        raise CanaryError(message)


def load_canonical_json(path: Path, expected_sha256: str | None = None) -> dict[str, Any]:
    raw = path.read_bytes()
    if expected_sha256 is not None:
        require(sha256_bytes(raw) == expected_sha256, f"SHA-256 mismatch: {path}")
    value = json.loads(raw)
    require(isinstance(value, dict), f"JSON root must be an object: {path}")
    require(canonical_bytes(value) == raw, f"JSON must be canonical: {path}")
    return value


def normalize_method(value: Any) -> str | None:
    if value is None:
        return None
    require(isinstance(value, str), "procurement_method must be string or null")
    normalized = value.strip().upper()
    require(normalized == value.strip().upper(), "method normalization must be case-only")
    return normalized


def validate_snapshot(snapshot: dict[str, Any], protocol: dict[str, Any]) -> list[dict[str, Any]]:
    required = protocol["input_contract"]
    require(snapshot.get("schema") == required["required_snapshot_schema"], "semantic snapshot schema mismatch")
    require(snapshot.get("terminal_state") == required["required_terminal_state"], "semantic terminal mismatch")
    require(snapshot.get("stage") == required["source_stage"], "semantic stage mismatch")
    require(snapshot.get("grain") == required["required_grain"], "semantic grain mismatch")
    require(snapshot.get("analysis_cutoff") == required["analysis_cutoff"], "semantic cutoff mismatch")
    require(snapshot.get("quarantine") == [], "semantic quarantine must be empty")
    require(snapshot.get("input_conservation_observed") is True, "semantic input conservation not observed")
    governance = snapshot.get("governance", {})
    require(governance.get("stage09_canary_input_ready") is True, "Stage 09 canary input is not ready")
    require(governance.get("stage09_global_unblocked") is False, "global Stage 09 must remain blocked")
    require(governance.get("production_modified") is False, "upstream production mutation detected")
    records = snapshot.get("records")
    require(isinstance(records, list), "semantic records must be a list")
    require(len(records) == snapshot.get("counts", {}).get("eligible_records"), "eligible count mismatch")
    require(len(records) == snapshot.get("counts", {}).get("input_rows"), "input row count mismatch")
    seen: set[str] = set()
    required_fields = set(required["required_record_fields"])
    allowed_roles = required["allowed_role_triples"]
    for record in records:
        require(isinstance(record, dict), "semantic record must be an object")
        require(required_fields <= set(record), "semantic record missing required fields")
        event_id = record["event_id"]
        require(isinstance(event_id, str) and event_id not in seen, "duplicate or invalid event_id")
        seen.add(event_id)
        require(record["currency"] == required["required_currency"], "currency mismatch")
        require(record["resolution_state"] in required["allowed_resolution_states"], "resolution state mismatch")
        triple = [record["event_role"], record["amount_role"], record["date_role"]]
        require(triple in allowed_roles, "event/amount/date role mismatch")
        require(isinstance(record["amount_hnl"], (int, float)) and not isinstance(record["amount_hnl"], bool), "amount must be numeric")
        require(record["amount_hnl"] >= 0, "amount must be nonnegative")
        for field in ("semantic_record_sha256", "source_lineage_sha256", "source_record_sha256"):
            require(isinstance(record[field], str) and HEX64.fullmatch(record[field]) is not None, f"invalid {field}")
        low = record["low_competition"]
        require(low is None or isinstance(low, bool), "low_competition must be bool or null")
        bid = record["bid_count"]
        require(bid is None or (isinstance(bid, int) and not isinstance(bid, bool) and bid >= 0), "bid_count must be nonnegative int or null")
        require(isinstance(record["supplier_missing"], bool), "supplier_missing must be bool")
    return records


def evaluate(snapshot: dict[str, Any], protocol: dict[str, Any], reference_contract: dict[str, Any]) -> dict[str, Any]:
    records = validate_snapshot(snapshot, protocol)
    population = protocol["analysis_population"]
    eligible = [
        r for r in records
        if r["event_role"] == population["event_role"]
        and r["amount_role"] == population["amount_role"]
        and r["date_role"] == population["date_role"]
    ]
    excluded = [r for r in records if r not in eligible]
    groups = protocol["hypothesis"]["groups"]
    group_counts = {group: 0 for group in groups}
    observed_counts = {group: 0 for group in groups}
    positive_counts = {group: 0 for group in groups}
    unsupported_methods: list[str] = []
    for record in eligible:
        method = normalize_method(record["procurement_method"])
        if method not in group_counts:
            unsupported_methods.append("NULL" if method is None else method)
            continue
        group_counts[method] += 1
        outcome = record["low_competition"]
        if outcome is not None:
            observed_counts[method] += 1
            positive_counts[method] += int(outcome)

    minimum = protocol["statistics"]["minimum_cell_n"]
    reasons: list[str] = []
    if len(eligible) < minimum * len(groups):
        reasons.append("INSUFFICIENT_TOTAL_ELIGIBLE_CONTRACT_RECORDS")
    if any(group_counts[g] < minimum for g in groups):
        reasons.append("MINIMUM_GROUP_CELL_NOT_MET")
    if any(group_counts[g] == 0 for g in groups):
        reasons.append("REQUIRED_GROUP_ABSENT")
    if any(observed_counts[g] < minimum for g in groups):
        reasons.append("MINIMUM_OBSERVED_OUTCOME_CELL_NOT_MET")
    if sum(observed_counts.values()) == 0:
        reasons.append("OUTCOME_COMPLETELY_MISSING_IN_ELIGIBLE_POPULATION")
    if unsupported_methods:
        reasons.append("ELIGIBLE_METHOD_OUTSIDE_PREREGISTERED_GROUPS")

    require(reasons, "real canary unexpectedly reached inferential execution")
    require(reference_contract["statistics"]["minimum_cell_n"] == minimum == 5, "minimum cell threshold changed")
    require(reference_contract["hypotheses"][0]["id"] == protocol["hypothesis"]["id"], "hypothesis id changed")
    require(reference_contract["hypotheses"][0]["test"] == protocol["hypothesis"]["test"], "test changed")
    require(reference_contract["statistics"]["fdr_method"] == protocol["statistics"]["fdr_method"], "FDR method changed")
    require(reference_contract["statistics"]["fdr_q"] == protocol["statistics"]["fdr_q"], "FDR threshold changed")

    record_commitments = sorted(r["semantic_record_sha256"] for r in records)
    eligible_commitments = sorted(r["semantic_record_sha256"] for r in eligible)
    excluded_by_role: dict[str, int] = {}
    for record in excluded:
        excluded_by_role[record["event_role"]] = excluded_by_role.get(record["event_role"], 0) + 1

    return {
        "schema": "data-science-pipeline/analyze-real-canary-result/1",
        "coordination_id": protocol["coordination_id"],
        "stage": "09 — Analyze",
        "terminal_state": "ANALYSIS_NOT_EVALUABLE",
        "reason_code": "NOT_EVALUABLE_MIN_CELL_SIZE",
        "reason_codes": reasons,
        "input": {
            "semantic_snapshot_sha256": protocol["upstream"]["semantic_snapshot_sha256"],
            "semantic_schema": snapshot["schema"],
            "semantic_terminal_state": snapshot["terminal_state"],
            "input_rows": len(records),
            "record_commitments_sha256": sha256_bytes(canonical_bytes(record_commitments)),
        },
        "population": {
            "event_role": population["event_role"],
            "amount_role": population["amount_role"],
            "date_role": population["date_role"],
            "eligible_records": len(eligible),
            "eligible_record_commitments": eligible_commitments,
            "excluded_records": len(excluded),
            "excluded_by_event_role": dict(sorted(excluded_by_role.items())),
            "unsupported_preregistered_methods": sorted(unsupported_methods),
        },
        "preregistered_hypothesis": {
            "id": protocol["hypothesis"]["id"],
            "groups": groups,
            "outcome": protocol["hypothesis"]["outcome"],
            "test": protocol["hypothesis"]["test"],
            "effect": protocol["hypothesis"]["effect"],
            "minimum_cell_n": minimum,
            "group_counts": group_counts,
            "observed_outcome_counts": observed_counts,
            "positive_outcome_counts": positive_counts,
        },
        "inference": {
            "test_executed": False,
            "p_value": None,
            "effect_size": None,
            "confidence_interval": None,
            "fdr_applied": False,
            "fdr_adjusted_p_value": None,
            "negative_control_executed": False,
            "model_fit_performed": False,
            "outlier_candidates_emitted": 0,
        },
        "missingness": {
            "eligible_bid_count_missing": sum(r["bid_count"] is None for r in eligible),
            "eligible_low_competition_missing": sum(r["low_competition"] is None for r in eligible),
            "silent_imputations": 0,
        },
        "claim_boundary": {
            "association_claims": 0,
            "causal_claims": 0,
            "wrongdoing_claims": 0,
            "public_rankings": 0,
            "relationship_validation_claims": 0,
        },
        "readiness": {
            "bounded_canary_completed": True,
            "stage10_canary_input_ready": False,
            "stage10_global_unblocked": False,
        },
        "governance": {
            "external_real_data_evaluations": 1,
            "external_cost_usd": 0.0,
            "production_modified": False,
            "mass_processing_authorized": False,
            "merge_authorized": False,
            "scientific_promotion_credit": 0,
        },
    }


def run(snapshot_path: Path, protocol_path: Path, reference_contract_path: Path, output_path: Path) -> dict[str, Any]:
    protocol = load_canonical_json(protocol_path)
    snapshot = load_canonical_json(snapshot_path, protocol["upstream"]["semantic_snapshot_sha256"])
    reference = load_canonical_json(reference_contract_path, protocol["analyze_reference"]["analysis_contract_sha256"])
    result = evaluate(snapshot, protocol, reference)
    output_path.write_bytes(canonical_bytes(result))
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--snapshot", type=Path, required=True)
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--reference-contract", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = run(args.snapshot, args.protocol, args.reference_contract, args.output)
    print(result["terminal_state"], result["reason_code"])


if __name__ == "__main__":
    main()
