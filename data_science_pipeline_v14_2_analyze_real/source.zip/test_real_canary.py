from __future__ import annotations

import copy
import hashlib
import json
import tempfile
import unittest
from pathlib import Path

import run_real_canary as r

HERE = Path(__file__).resolve().parent
SNAPSHOT_PATH = HERE / "REAL_SEMANTIC_SNAPSHOT.json"
PROTOCOL_PATH = HERE / "ANALYSIS_REAL_CANARY_CONTRACT.json"
REFERENCE_PATH = HERE / "reference_ANALYSIS_CONTRACT.json"


def load(path: Path):
    return json.loads(path.read_text())


class RealAnalyzeCanaryTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.snapshot = load(SNAPSHOT_PATH)
        cls.protocol = load(PROTOCOL_PATH)
        cls.reference = load(REFERENCE_PATH)

    def evaluate(self, snapshot=None, protocol=None, reference=None):
        return r.evaluate(
            copy.deepcopy(self.snapshot if snapshot is None else snapshot),
            copy.deepcopy(self.protocol if protocol is None else protocol),
            copy.deepcopy(self.reference if reference is None else reference),
        )

    def assert_error(self, mutate, pattern):
        snapshot = copy.deepcopy(self.snapshot)
        mutate(snapshot)
        with self.assertRaisesRegex(r.CanaryError, pattern):
            r.evaluate(snapshot, copy.deepcopy(self.protocol), copy.deepcopy(self.reference))

    def test_01_real_result_is_not_evaluable(self):
        self.assertEqual(self.evaluate()["terminal_state"], "ANALYSIS_NOT_EVALUABLE")

    def test_02_primary_reason_is_min_cell(self):
        self.assertEqual(self.evaluate()["reason_code"], "NOT_EVALUABLE_MIN_CELL_SIZE")

    def test_03_input_rows_are_two(self):
        self.assertEqual(self.evaluate()["input"]["input_rows"], 2)

    def test_04_contract_population_is_one(self):
        self.assertEqual(self.evaluate()["population"]["eligible_records"], 1)

    def test_05_payment_is_excluded(self):
        result = self.evaluate()
        self.assertEqual(result["population"]["excluded_by_event_role"], {"PAYMENT": 1})

    def test_06_open_group_count_is_one(self):
        self.assertEqual(self.evaluate()["preregistered_hypothesis"]["group_counts"]["OPEN"], 1)

    def test_07_direct_group_count_is_zero(self):
        self.assertEqual(self.evaluate()["preregistered_hypothesis"]["group_counts"]["DIRECT"], 0)

    def test_08_observed_outcomes_are_zero(self):
        result = self.evaluate()["preregistered_hypothesis"]["observed_outcome_counts"]
        self.assertEqual(result, {"DIRECT": 0, "OPEN": 0})

    def test_09_bid_count_missing_is_preserved(self):
        self.assertEqual(self.evaluate()["missingness"]["eligible_bid_count_missing"], 1)

    def test_10_low_competition_missing_is_preserved(self):
        self.assertEqual(self.evaluate()["missingness"]["eligible_low_competition_missing"], 1)

    def test_11_silent_imputations_zero(self):
        self.assertEqual(self.evaluate()["missingness"]["silent_imputations"], 0)

    def test_12_test_not_executed(self):
        self.assertFalse(self.evaluate()["inference"]["test_executed"])

    def test_13_p_value_is_null(self):
        self.assertIsNone(self.evaluate()["inference"]["p_value"])

    def test_14_effect_is_null(self):
        self.assertIsNone(self.evaluate()["inference"]["effect_size"])

    def test_15_interval_is_null(self):
        self.assertIsNone(self.evaluate()["inference"]["confidence_interval"])

    def test_16_fdr_not_applied(self):
        self.assertFalse(self.evaluate()["inference"]["fdr_applied"])

    def test_17_negative_control_not_executed(self):
        self.assertFalse(self.evaluate()["inference"]["negative_control_executed"])

    def test_18_model_not_fit(self):
        self.assertFalse(self.evaluate()["inference"]["model_fit_performed"])

    def test_19_no_claims_or_rankings(self):
        self.assertTrue(all(value == 0 for value in self.evaluate()["claim_boundary"].values()))

    def test_20_stage10_remains_blocked(self):
        ready = self.evaluate()["readiness"]
        self.assertFalse(ready["stage10_canary_input_ready"])
        self.assertFalse(ready["stage10_global_unblocked"])

    def test_21_governance_is_zero_cost_no_production(self):
        gov = self.evaluate()["governance"]
        self.assertEqual(gov["external_cost_usd"], 0.0)
        self.assertFalse(gov["production_modified"])
        self.assertEqual(gov["scientific_promotion_credit"], 0)

    def test_22_replay_is_byte_identical(self):
        with tempfile.TemporaryDirectory() as tmp:
            a, b = Path(tmp) / "a.json", Path(tmp) / "b.json"
            r.run(SNAPSHOT_PATH, PROTOCOL_PATH, REFERENCE_PATH, a)
            r.run(SNAPSHOT_PATH, PROTOCOL_PATH, REFERENCE_PATH, b)
            self.assertEqual(a.read_bytes(), b.read_bytes())

    def test_23_row_order_invariant(self):
        first = self.evaluate()
        snapshot = copy.deepcopy(self.snapshot)
        snapshot["records"].reverse()
        second = self.evaluate(snapshot=snapshot)
        self.assertEqual(first, second)

    def test_24_snapshot_schema_mismatch_fails(self):
        self.assert_error(lambda s: s.__setitem__("schema", "bad"), "schema mismatch")

    def test_25_semantic_terminal_mismatch_fails(self):
        self.assert_error(lambda s: s.__setitem__("terminal_state", "SEMANTIC_QUARANTINED"), "terminal mismatch")

    def test_26_nonempty_quarantine_fails(self):
        self.assert_error(lambda s: s.__setitem__("quarantine", ["x"]), "quarantine")

    def test_27_input_conservation_false_fails(self):
        self.assert_error(lambda s: s.__setitem__("input_conservation_observed", False), "conservation")

    def test_28_duplicate_event_id_fails(self):
        def mutate(s):
            s["records"][1]["event_id"] = s["records"][0]["event_id"]
        self.assert_error(mutate, "duplicate")

    def test_29_currency_mismatch_fails(self):
        self.assert_error(lambda s: s["records"][0].__setitem__("currency", "USD"), "currency")

    def test_30_role_mismatch_fails(self):
        self.assert_error(lambda s: s["records"][0].__setitem__("amount_role", "PAYMENT_VALUE"), "role mismatch")

    def test_31_bad_lineage_hash_fails(self):
        self.assert_error(lambda s: s["records"][0].__setitem__("source_lineage_sha256", "x"), "source_lineage")

    def test_32_negative_bid_count_fails(self):
        self.assert_error(lambda s: s["records"][0].__setitem__("bid_count", -1), "bid_count")

    def test_33_nonboolean_outcome_fails(self):
        self.assert_error(lambda s: s["records"][0].__setitem__("low_competition", 1), "low_competition")

    def test_34_negative_amount_fails(self):
        self.assert_error(lambda s: s["records"][0].__setitem__("amount_hnl", -1), "amount")

    def test_35_minimum_cell_threshold_cannot_change(self):
        protocol = copy.deepcopy(self.protocol)
        protocol["statistics"]["minimum_cell_n"] = 1
        with self.assertRaisesRegex(r.CanaryError, "threshold changed"):
            self.evaluate(protocol=protocol)

    def test_36_hypothesis_id_cannot_change(self):
        protocol = copy.deepcopy(self.protocol)
        protocol["hypothesis"]["id"] = "H09-CHANGED"
        with self.assertRaisesRegex(r.CanaryError, "hypothesis id changed"):
            self.evaluate(protocol=protocol)

    def test_37_test_cannot_change(self):
        protocol = copy.deepcopy(self.protocol)
        protocol["hypothesis"]["test"] = "chi_square"
        with self.assertRaisesRegex(r.CanaryError, "test changed"):
            self.evaluate(protocol=protocol)

    def test_38_fdr_method_cannot_change(self):
        protocol = copy.deepcopy(self.protocol)
        protocol["statistics"]["fdr_method"] = "Bonferroni"
        with self.assertRaisesRegex(r.CanaryError, "FDR method changed"):
            self.evaluate(protocol=protocol)

    def test_39_fdr_threshold_cannot_change(self):
        protocol = copy.deepcopy(self.protocol)
        protocol["statistics"]["fdr_q"] = 0.10
        with self.assertRaisesRegex(r.CanaryError, "FDR threshold changed"):
            self.evaluate(protocol=protocol)

    def test_40_noncanonical_snapshot_file_fails(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "snapshot.json"
            path.write_text(json.dumps(self.snapshot, indent=2) + "\n")
            with self.assertRaisesRegex(r.CanaryError, "SHA-256 mismatch"):
                r.run(path, PROTOCOL_PATH, REFERENCE_PATH, Path(tmp) / "out.json")

    def test_41_tampered_snapshot_hash_fails(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "snapshot.json"
            value = copy.deepcopy(self.snapshot)
            value["records"][0]["amount_hnl"] += 1
            path.write_bytes(r.canonical_bytes(value))
            with self.assertRaisesRegex(r.CanaryError, "SHA-256 mismatch"):
                r.run(path, PROTOCOL_PATH, REFERENCE_PATH, Path(tmp) / "out.json")

    def test_42_contract_hash_is_exact(self):
        self.assertEqual(r.sha256_path(REFERENCE_PATH), self.protocol["analyze_reference"]["analysis_contract_sha256"])

    def test_43_snapshot_hash_is_exact(self):
        self.assertEqual(r.sha256_path(SNAPSHOT_PATH), self.protocol["upstream"]["semantic_snapshot_sha256"])

    def test_44_record_commitment_is_order_stable(self):
        first = self.evaluate()["input"]["record_commitments_sha256"]
        snapshot = copy.deepcopy(self.snapshot)
        snapshot["records"].reverse()
        second = self.evaluate(snapshot=snapshot)["input"]["record_commitments_sha256"]
        self.assertEqual(first, second)


if __name__ == "__main__":
    unittest.main(verbosity=2)
